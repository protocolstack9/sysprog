/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-18 (p.31): Write a program to remove trailing blanks and tabs from each
 *              line of input, and to delete entirely blank lines.
 *
 * It is easy to solve this problem with limitation on the max. length of an
 * input line. Such limitation not allowed, the storage whose size is variable
 * is necessary to remember a arbitrarily long sequence of whitespaces in case
 * it is not a trailing sequence. Since malloc() has not been introduced yet in
 * the book, a complete solution for this problem is impossible, however. Thus,
 * this solution just tries to remove as many trailing blanks and tabs as
 * possible.
 *
 * The trick using main()'s return value for graceful degrading is credited to
 * Ben Pfaff.
 *
 * Furthermore, the answer can be more improved by introducing a queue instead
 * of a simple buffer for keeping accumulated blanks. The queue helps to
 * minimize the number of overflowed blanks from the buffer; for example,
 * assuming that the buffer can contains 10 blanks, when 11 trailing spaces are
 * encountered, the simple buffer hired here prints out 10 spaces getting rid of
 * only the last space while the queue prints out the first space getting rid of
 * the following 10 spaces.
 */

#include <stdio.h>
#include <stdlib.h>

#define MAX_BLANK 80

main()
{
    int c;
    int i;
    int blankline;    /* indicates line may be entirely blank */
    int buffull;      /* indicates buffer has been filled fully before */
    int result;       /* main()'s return value */
    char blank[MAX_BLANK];    /* accumulates blanks here */

    i = 0;
    blankline = 1;
    buffull = 0;
    result = EXIT_SUCCESS;
    while ((c = getchar()) != EOF) {
        if (c == ' ' || c == '\t') {
            if (i > MAX_BLANK-1) {    /* buffer for blanks full */
                buffull = 1;
                printf("%.*s", i, blank);
                i = 0;
                blankline = 0;    /* important when entirely blank line contains
                                     more than (MAX_BLANK-1) blanks */
            }
            blank[i++] = c;    /* collects blanks */
        } else {
            if (c == '\n') {
                if (buffull)    /* trailing blanks remain */
                    result = EXIT_FAILURE;
                if (!blankline)    /* not entirely blank */
                    putchar(c);
                blankline = 1;
            } else {
                printf("%.*s", i, blank);    /* blanks before or between chars */
                putchar(c);
                blankline = 0;
            }
            buffull = 0;
            i = 0;
        }
    }
    if (buffull)    /* for last line with no newline */
        result = EXIT_FAILURE;

    return result;
}


/* end of 1-18-3.c */
