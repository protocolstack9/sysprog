/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-13
 *
 * 1-22 (p.34): Write a program to "fold" long input lines into two or more
 *              shorter lines after the last non-blank character that occurs
 *              before the n-th column of input. Make sure your program does
 *              something intelligent with very long lines, and if there are no
 *              blanks or tabs before the specified column.
 *
 * This solution tries to preserve spaces in the input; for example, preceding
 * or trailing blanks are printed out untouched, and spaces resulted from
 * expanding a tab are dealt with in the same way. Thus, getting folded lines
 * back to one by splicing them recovers the original form.
 */

#include <stdio.h>

#define MAX_LINE 80    /* number of chars in a line */
#define TAB_STOP 8

int getline(char s[], int lim);
int foldpos(char s[], int len);

main()
{
    int len, max, pos;
    char s[MAX_LINE+2];    /* MAX_LINE + newline + null */

    max = MAX_LINE+2;
    while ((len = getline(s, max)) > 0) {
        if (s[len-1] != '\n') {    /* long line, so fold */
            pos = foldpos(s, len);
            printf("%.*s\n%s", pos+1, s, &s[pos+1]);
        } else {
            printf("%s", s);
            pos = len - 1;
        }
        max = MAX_LINE - (len-pos-1) + 2;
    }

    return 0;
}

int getline(char s[], int lim)
{
    static int space, cnt;

    int i;
    int c;

    i = 0;
    while (space-- > 0 && i < lim-1) {    /* for spanning-over spaces */
        s[i++] = ' ';
        cnt++;
    }

    while (i < lim-1 && (c = getchar()) != EOF && c != '\n') {
        if (c == '\t') {    /* expands a tab */
            space = TAB_STOP - (cnt % TAB_STOP);
            while (space-- > 0 && i < lim-1) {
                s[i++] = ' ';
                cnt++;
            }
        } else {
            s[i++] = c;
            cnt++;
        }
    }

    if (c == '\n') {
        s[i++] = c;
        cnt = 0;
    } else if (c == EOF && cnt > 0) {    /* for the last line with no newline */
        /* no need to use ungetc() (see 1-16.c) because of using cnt in
           condition expression instead of idx */
        s[i++] = '\n';
        cnt = 0;
    }
    s[i] = 0;

    return i;
}

int foldpos(char s[], int len)
{
    int j;

    len -= 2;    /* backs off null char and last extra char */

    /* note that len can be -1 here when s[] carries only the extra char (this
       occurs when a line containing a space and at least MAX_LINE following
       non-space chars given, or when MAX_LINE is 1); it works well, however,
       even if foldpos() returns -1 */

    j = len;
    while (j >= 0 && s[j] != ' ')
        j--;

    if (j < 0)    /* no space, thus forcibly fold */
        j = len;

    return j;
}


/* end of 1-22-2.c */
