/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-13
 *
 * 1-16: Revise the main routine of the longest-line program so it will
 *       correctly print the length of arbitrarily long input lines, and as much
 *       as possible of the text.
 *
 * Assuming that the main routine referred to by the problem is the main
 * function, this answer only modifies the main function with geline()
 * untouched.
 *
 * The modification on getline() below has nothing to do with solving the
 * problem, rather it is to allow for an implementation where the last line of a
 * file need not end with the newline character.
 */

#include <stdio.h>

#define MAX_LINE 80    /* max input line length */

int getline(char s[], int lim);
void copy(char to[], char from[]);

/* print longest input line */
main()
{
    int len;     /* current line length */
    int max;     /* maximum length seen so far */
    int more;    /* in reading long line */
    int tmax;    /* accumulated length of long line */
    char line[MAX_LINE];       /* current input line */
    char longest[MAX_LINE];    /* longest line saved here */
    char temp[MAX_LINE];       /* starting part of long line */

    more = 0;
    max = 0;
    while ((len = getline(line, MAX_LINE)) > 0) {
        if (line[len-1] != '\n') {    /* needs to read more */
            if (more == 0) {    /* start of long line */
                more = 1;
                copy(temp, line);
                tmax = 0;
            }
            tmax += len;
        } else {    /* line completed */
            if (more == 1) {
                more = 0;
                len += tmax;
                copy(line, temp);
                line[MAX_LINE-1] = '\n';
            }
            if (len > max) {    /* replaces longest line */
                max = len;
                copy(longest, line);
            }
        }
    }

    if (max > 0)   /* there was a line */
        printf("%d, %s", max, longest);

    return 0;
}


int getline(char s[], int lim)
{
    int c, i;

    for (i = 0; i < lim-1 && ((c = getchar()) != EOF && c != '\n'); ++i)
        s[i] = c;

    if (c == '\n') {
        s[i] = c;
        ++i;
    } else if (c == EOF) {    /* for the last line with no newline */
        if (i > 0) {
            s[i] = '\n';
            ++i;
        }
    } else {
        /* if the buffer is full and the next call to getchar() gives EOF, the
           next call to getline() will return 0 rather than correctly compensate
           the missing newline; this modification is for such a case */
        c = getchar();
        ungetc((c == EOF)? '\n': c, stdin);
    }
    s[i] = '\0';

    return i;
}


void copy(char to[], char from[])
{
    int i;

    i = 0;
    while ((to[i]=from[i]) != '\0')
        ++i;
}


/* end of 1-16.c */
