/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-6 (p.17): Verify that the expression getchar() != EOF is 0 or 1.
 */

#include <stdio.h>

main()
{
    int c;

    while (c = (getchar() != EOF))
        printf("(getchar() != EOF) is %d\n", c);
    printf("(getchar() != EOF) is %d when meets EOF\n", c);
}


/* end of 1-06.c */
