/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-5 (p.14): Modify the temperature conversion program to print the table in
 *             reverse order, that is, from 300 degree to 0.
 */

#include <stdio.h>

main()
{
    int fahr;

    for (fahr = 300; fahr >= 0; fahr = fahr - 20)
        printf("%3d %6.1f\n", fahr, (5.0/9.0)*(fahr-32));
}


/* end of 1-05.c */
