/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-12
 *
 * 1-17 (p.31): Write a program to print all input lines that are longer than 80
 *              characters.
 *
 * Note that the newline character terminating a line also counts as a
 * character.
 *
 * For the modification on getline() below, see 1-16.c.
 */

#include <stdio.h>

#define MIN_LINE 81

int getline(char s[], int len);

main()
{
    int len;
    int longline;    /* line longer than 80 chars */
    char line[MIN_LINE];

    longline = 0;
    while ((len = getline(line, MIN_LINE)) > 0) {
        if (line[len-1] != '\n') {    /* long line */
            longline = 1;
            printf("%s", line);
        } else {    /* line completed */
            if (longline == 1)
                printf("%s", line);
            longline = 0;
        }
    }

    return 0;
}


int getline(char s[], int lim)
{
    int c, i;

    for (i = 0; i < lim-1 && ((c = getchar()) != EOF && c != '\n'); ++i)
        s[i] = c;

    if (c == '\n') {
        s[i] = c;
        ++i;
    } else if (c == EOF) {    /* for the last line with no newline */
        if (i > 0) {
            s[i] = '\n';
            ++i;
        }
    } else {
        c = getchar();
        ungetc((c == EOF)? '\n': c, stdin);
    }
    s[i] = '\0';

    return i;
}


/* end of 1-17.c */
