/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-10 (p.20): Write a program to copy its input to its output, replacing each
 *              tab by \t, each backspace by \b, and each backslash by \\. This
 *              makes tabs and backspaces visible in an unambiguous way.
 *
 * Using if-else or switch can improve the code.
 */

#include <stdio.h>

main()
{
    int c;
    int ordinary;

    while ((c = getchar()) != EOF) {
        ordinary = 1;
        if (c == '\t') {
            printf("\\t");
            ordinary = 0;
        }
        if (c == '\b') {
            printf("\\b");
            ordinary = 0;
        }
        if (c == '\\') {
            printf("\\\\");
            ordinary = 0;
        }
        if (ordinary)
            putchar(c);
    }
}


/* end of 1-10-1.c */
