/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-23 (p.34): Write a program to remove all comments from a C program. Don't
 *              forget to handle quoted strings and character constants
 *              properly, C comments do not nest.
 *
 * It is not easy to completely recognize comments in C code because it requires
 * to deal with many complexities in the language definition such as replacing
 * trigraphs, handling preprocessing directives and so on. This answer assumes
 * that the input code has already been processed by a preprocessor and has no
 * trigraphs.
 *
 * This solution just removes comments rather than replaces them with spaces.
 * If the replacement is desired, just activate the commented-out call to
 * putchar() in the "case ENDCMT" branch.
 *
 * The state-machine used in this solution can also be implemented with several
 * separate functions.
 */

#include <assert.h>
#include <stdio.h>

#define PROGRAM  0
#define STARTCMT 1
#define COMMENT  2
#define ENDCMT   3
#define LITERAL  4

main()
{
    int state;
    int c, q;

    state = PROGRAM;
    while ((c = getchar()) != EOF) {
        switch(state) {
            case STARTCMT:
                if (c == '*') {
                    state = COMMENT;
                    break;
                } else {
                    putchar('/');
                    state = PROGRAM;
                }
                /* no break */
            case PROGRAM:
                if (c == '/')
                    state = STARTCMT;
                else {
                    putchar(c);
                    if (c == '\'' || c == '"') {
                        q = c;
                        state = LITERAL;
                    }
                }
                break;
            case COMMENT:
                if (c == '*')
                    state = ENDCMT;
                break;
            case ENDCMT:
                if (c == '/') {
                    /* putchar(' '); */
                    state = PROGRAM;
                } else if (c != '*')
                    state = COMMENT;
                break;
            case LITERAL:
                putchar(c);
                if (c == '\\') {
                    c = getchar();
                    if (c != EOF)
                        putchar(c);
                } else if (c == q)
                    state = PROGRAM;
                break;
            default:
                assert(!"invalid state -- should never reach here");
                break;
        }
    }

    if (state == STARTCMT && c == EOF)
        putchar('/');

    return 0;
}


/* end of 1-23-2.c */
