/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-11 (p.21): How would you test the word count program? What kinds of input
 *              are most likely to uncover bugs if there are any?
 *
 * This code produces various files that can be used to test the word count
 * program. The files generated have names beginning with "test" and
 * three-character extension "txt". The two-digit number explains how each file
 * can be used to test the word count program:
 *
 * 1: input contains no characters (if an empty file supported)
 * 2: input contains just a few newlines but nothing
 * 3: input contains INT_MAX+10 newlines but nothing
 * 4: input contains INT_MAX+10 whitespaces between two words
 * 5: input contains INT_MAX+10 words on a few lines
 * 6: input contains INT_MAX+10 words on a line
 * 7: input contains INT_MAX+10 one-character words
 * 8: input contains a (INT_MAX+10)-character word
 * 9: input lines begin with a sequence of whitespaces before a word
 * a: input lines begin with a word following some whitespaces (if supported)
 * b: input does not end with a newline (if supported)
 *
 * In addition, the following cases can be used to see how well the word count
 * program handles exceptional cases:
 *
 *  - input contains an arbitrary byte sequence
 *  - /dev/null is given as input
 *
 * Note that this program may produce extremely huge files; if those files make
 * a trouble in your system, modify the value of limit below properly.
 */

#include <assert.h>
#include <stdio.h>
#include <limits.h>

#define OPEN(n) do {                                       \
                    assert(n >= 0 && n < 16);              \
                    sprintf(filename, "test%x.txt", n);    \
                    fp = fopen(filename, "w");             \
                    assert(fp);                            \
                } while(0)

#define CLOSE() fclose(fp)

main()
{
    FILE *fp;
    unsigned long i, j, limit;
    char filename[] = "testxx.txt";
    const char whitespace[] = " \t\n\f\v\r";
    const char alpha[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const char word[] = "test";

    limit = INT_MAX;

    /* 1. contains no characters */
    OPEN(1);
    CLOSE();

    /* 2. contains a few newlines only */
    OPEN(2);
    for (i = 0; i < 5; i++)
        fprintf(fp, "\n");
    CLOSE();

    /* 3. contains many newlines only */
    OPEN(3);
    for (i = 0; i < limit; i++)
        fprintf(fp, "\n");
    for (i = 0; i < 10; i++)
        fprintf(fp, "\n");
    CLOSE();

    /* 4. contains many whitespaces between two words */
    OPEN(4);
    fprintf(fp, "%s", word);
    for (i = 0; i < limit; i++)
        fprintf(fp, "%c", whitespace[i % (sizeof(whitespace)-1)]);
    for (i = 0; i < 10; i++)
        fprintf(fp, "%c", whitespace[i % (sizeof(whitespace)-1)]);
    fprintf(fp, "%s\n", word);
    CLOSE();

    /* 5. contains many words on a few lines */
    OPEN(5);
    for (i = 0; i < 5; i++) {
        for (j = 0; j < limit / 5; j++)
            fprintf(fp, (j == 0)? "%s": " %s", word);
        fprintf(fp, "\n");
    }
    if (limit % 5 != 0) {
        for (i = 0; i < limit%5 + 10; i++)
            fprintf(fp, (i == 0)? "%s": " %s", word);
        fprintf(fp, "\n");
    }
    CLOSE();

    /* 6. contains many words on a line */
    OPEN(6);
    for (i = 0; i < limit; i++)
        fprintf(fp, (i == 0)? "%s": " %s", word);
    for (i = 0; i < 10; i++)
        fprintf(fp, " %s", word);
    fprintf(fp, "\n");
    CLOSE();

    /* 7. contains many one-character words */
    OPEN(7);
    for (i = 0; i < 5; i++) {
        for (j = 0; j < limit / 5; j++)
            fprintf(fp, (j == 0)? "%c": " %c", alpha[j % (sizeof(alpha)-1)]);
        fprintf(fp, "\n");
    }
    if (limit % 5 != 0) {
        for (i = 0; i < limit%5 + 10; i++)
            fprintf(fp, (i == 0)? "%c": " %c", alpha[i % (sizeof(alpha)-1)]);
        fprintf(fp, "\n");
    }
    CLOSE();

    /* 8. contains a long word */
    OPEN(8);
    for (i = 0; i < limit; i++)
        fprintf(fp, "%c", alpha[i % (sizeof(alpha)-1)]);
    for (i = 0; i < 10; i++)
        fprintf(fp, "%c", alpha[i % (sizeof(alpha)-1)]);
    fprintf(fp, "\n");
    CLOSE();

    /* 9. begins some whitespaces before a word */
    OPEN(9);
    for (i = 0; i < 10; i++)
        fprintf(fp, "%s%s\n", whitespace, word);
    CLOSE();

    /* 10. begins a word following some whitespaces */
    OPEN(10);
    for (i = 0; i < 10; i++)
        fprintf(fp, "%s%s\n", word, whitespace);
    CLOSE();

    /* 11. does not end with a newline */
    OPEN(11);
    for (i = 0; i < 10; i++)
        fprintf(fp, "%s%s", word, (i < 9)? "\n": "");
    CLOSE();

    return 0;
}


/* end of 1-11.c */
