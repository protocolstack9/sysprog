/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-23 (p.34): Write a program to remove all comments from a C program. Don't
 *              forget to handle quoted strings and character constants
 *              properly, C comments do not nest.
 *
 * It is not easy to completely recognize comments in C code because it requires
 * to deal with many complexities in the language definition such as replacing
 * trigraphs, handling preprocessing directives and so on. This answer assumes
 * that the input code has already been processed by a preprocessor and has no
 * trigraphs.
 *
 * This solution just removes comments rather than replaces them with spaces.
 * If the replacement is desired, just activate the commented-out call to
 * putchar() in endcmt().
 *
 * There is also a way to get the same behavior using ungetc() instead of
 * directly introducing states.
 */

#include <assert.h>
#include <stdio.h>

#define cs(i) (table[i][0])    /* current state */
#define ch(i) (table[i][1])    /* character */
#define ac(i) (table[i][2])    /* action */
#define ns(i) (table[i][3])    /* next state */

enum {    /* states */
    PROGRAM,
    STARTCMT,
    COMMENT,
    ENDCMT,
    LITERALS,
    LITERALD,
    ESCAPES,
    ESCAPED,
    END          /* should be last */
};

enum {    /* actions */
    CURRENT,
    SLASH,
    SLASHCRNT,
    IGNORE
};

void act(int action, int c)
{
    switch(action) {
        case SLASH:
            putchar('/');
            break;
        case SLASHCRNT:
            putchar('/');
            /* no break */
        case CURRENT:
            putchar(c);
            break;
        case IGNORE:
            break;
        default:
            assert(!"invalid action code -- should never reach here");
            break;
    }
}

main()
{
    static int table[][4] = {
        EOF,      0,    IGNORE,    EOF,         /* dummy line */
        /* program */
        PROGRAM,  '/',  IGNORE,    STARTCMT,
        PROGRAM,  '\'', CURRENT,   LITERALS,
        PROGRAM,  '"',  CURRENT,   LITERALD,
        PROGRAM,  EOF,  IGNORE,    END,
        PROGRAM,  '?',  CURRENT,   PROGRAM,     /* ? indicates any but EOF */
        /* start of comment */
        STARTCMT, '/',  SLASH,     STARTCMT,
        STARTCMT, '*',  IGNORE,    COMMENT,
        STARTCMT, '\'', SLASHCRNT, LITERALS,
        STARTCMT, '"',  SLASHCRNT, LITERALD,
        STARTCMT, EOF,  SLASH,     END,
        STARTCMT, '?',  SLASHCRNT, PROGRAM,
        /* comment */
        COMMENT,  '*',  IGNORE,    ENDCMT,
        COMMENT,  EOF,  IGNORE,    END,
        COMMENT,  '?',  IGNORE,    COMMENT,
        /* end of comment */
        ENDCMT,   '/',  IGNORE,    PROGRAM,
        ENDCMT,   '*',  IGNORE,    ENDCMT,
        ENDCMT,   EOF,  IGNORE,    END,
        ENDCMT,   '?',  IGNORE,    COMMENT,
        /* literal by ' */
        LITERALS, '\\', CURRENT,   ESCAPES,
        LITERALS, '\'', CURRENT,   PROGRAM,
        LITERALS, EOF,  IGNORE,    END,
        LITERALS, '?',  CURRENT,   LITERALS,
        /* literal by " */
        LITERALD, '\\', CURRENT,   ESCAPED,
        LITERALD, '"',  CURRENT,   PROGRAM,
        LITERALD, EOF,  IGNORE,    END,
        LITERALD, '?',  CURRENT,   LITERALD,
        /* escape sequence in literal by ' */
        ESCAPES,  EOF,  IGNORE,    END,
        ESCAPES,  '?',  CURRENT,   LITERALS,
        /* escape sequence in literal by " */
        ESCAPED,  EOF,  IGNORE,    END,
        ESCAPED,  '?',  CURRENT,   LITERALD,
        END,    /* should be last */
    }, s[END], e[END];

    int c;
    int i, state;

    assert(cs(1) != EOF);

    i = 1;
    do {
        if (cs(i) != cs(i-1)) {
            assert(cs(i) == END ||
                   (cs(i) >= 0 && cs(i) < sizeof(s)/sizeof(*s)));
            if (cs(i) != END)
                s[cs(i)] = i;
            if (cs(i-1) != END)
                e[cs(i-1)] = i;
        }
    } while(cs(i++) != END);

    for (i = 0; i < END; i++)
        assert(s[i] > 0 && e[i] > s[i]);

    state = PROGRAM;
    while (state != END) {
        c = getchar();

        assert(state >= 0 && state < sizeof(s)/sizeof(*s));
        for (i = s[state]; i < e[state] && c != ch(i) &&
                           !(c != EOF && ch(i) == '?'); i++)
            continue;
        assert(i < e[state]);

        act(ac(i), c);
        state = ns(i);
    }

    return 0;
}


/* end of 1-23-4 */
