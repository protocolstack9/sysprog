/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-23 (p.34): Write a program to remove all comments from a C program. Don't
 *              forget to handle quoted strings and character constants
 *              properly, C comments do not nest.
 *
 * It is not easy to completely recognize comments in C code because it requires
 * to deal with many complexities in the language definition such as replacing
 * trigraphs, handling preprocessing directives and so on. This answer assumes
 * that the input code has already been processed by a preprocessor and has no
 * trigraphs.
 *
 * This solution just removes comments rather than replaces them with spaces.
 * If the replacement is desired, just activate the commented-out call to
 * putchar() in the "end of comment" branch.
 */

#include <stdio.h>

main()
{
    int c;

    while ((c = getchar()) != EOF) {    /* program */
        if (c == '/') {    /* start of comment */
            c = getchar();
            if (c == '*') {    /* comment */
                while ((c = getchar()) != EOF) {
                    if (c == '*') {    /* end of comment */
                        c = getchar();
                        if (c == '/') {    /* back to program */
                            /* putchar(' '); */
                            break;
                        } else if (c == '*')
                            ungetc(c, stdin);    /* end of comment */
                    }
                }
            } else {    /* back to program */
                putchar('/');
                ungetc(c, stdin);
            }
        } else if (c == '\'' || c == '"') {    /* literal */
            int q = c;
            putchar(c);
            while ((c = getchar()) != EOF) {
                putchar(c);
                if (c == '\\') {
                    c = getchar();
                    if (c != EOF)
                        putchar(c);
                } else if (c == q)
                    break;
            }
        } else
            putchar(c);
    }

    return 0;
}


/* end of 1-23-5.c */
