/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-18 (p.31): Write a program to remove trailing blanks and tabs from each
 *              line of input, and to delete entirely blank lines.
 *
 * It is easy to solve this problem with limitation on the max. length of an
 * input line. Such limitation not allowed, the storage whose size is variable
 * is necessary to remember a arbitrarily long sequence of whitespaces in case
 * it is not a trailing sequence. Since malloc() has not been introduced yet in
 * the book, a complete solution for this problem is impossible, however. Thus,
 * this solution just tries to remove as many trailing blanks and tabs as
 * possible.
 *
 * This solution can be modified to degrade gracefully as suggested by Ben
 * Pfaff. Which means making main() return EXIT_FAILURE when there are trailing
 * blanks remained and repeatedly processing the output with the same program
 * until all trailing blanks completely removed, in which case main() returns
 * EXIT_SUCCESS. The key point here is to detect if there are trailing blanks
 * remained.
 */

#include <stdio.h>

#define MAX_BLANK 80

main()
{
    int c;
    int i;
    int blankline;    /* indicates line may be entirely blank */
    char blank[MAX_BLANK];    /* accumulates blanks here */

    i = 0;
    blankline = 1;
    while ((c = getchar()) != EOF) {
        if (c == ' ' || c == '\t') {
            if (i > MAX_BLANK-1) {    /* buffer for blanks full */
                printf("%.*s", i, blank);
                i = 0;
                blankline = 0;    /* important when entirely blank line contains
                                     more than (MAX_BLANK-1) blanks */
            }
            blank[i++] = c;    /* collects blanks */
        } else {
            if (c == '\n') {
                if (blankline == 0)    /* not entirely blank */
                    putchar(c);
                blankline = 1;
            } else {
                printf("%.*s", i, blank);    /* blanks before or between chars */
                putchar(c);
                blankline = 0;
            }
            i = 0;
        }
    }

    return 0;
}


/* end of 1-18-2.c */
