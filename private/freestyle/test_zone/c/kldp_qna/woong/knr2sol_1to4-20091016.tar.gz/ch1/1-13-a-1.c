/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-12
 *
 * 1-13A (p.24): Write a program to print a histogram of the lengths of words in
 *               its input. It is easy to draw the histogram with the bars
 *               horizontal;
 *
 * This answer simply ignores words longer than MAX_LEN. It is also possible
 * to count the number of words longer than MAX_LEN.
 */

#include <stdio.h>

#define MAX_LEN 15    /* max length of word */

main()
{
    int c;
    int i, len, store_len[MAX_LEN];
    int blank;    /* indicates blanks start */


    for (i = 0; i < MAX_LEN; ++i)
        store_len[i] = 0;

    len = 0;
    blank = 0;
    while ((c = getchar()) != EOF) {
        if (c == ' ' || c == '\n' || c == '\t') {
            if (!blank) {    /* end of word */
                if (len-1 < MAX_LEN)
                    store_len[len-1]++;
            }
            blank = 1;
        } else if (blank) {    /* beginning of word */
            blank = 0;
            len = 1;
        } else
            ++len;       /* inside word */
    }

    for (i = 0; i < MAX_LEN; ++i)
        if (store_len[i]) {
            printf("%3d-char (%4d): ", i+1, store_len[i]);
            while (store_len[i]-- > 0)
                putchar('*');
            putchar('\n');
        }
}


/* end of 1-13-a-1.c */
