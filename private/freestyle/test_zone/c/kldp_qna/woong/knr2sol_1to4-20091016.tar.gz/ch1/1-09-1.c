/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-9 (p.20): Write a program to copy its input to its output, replacing each
 *             string of one or more blanks by a single blank.
 *
 * Using the value of the previous character instead of the variable "blank"
 * and logical operatiors can improve the code.
 */

#include <stdio.h>

main()
{
    int c;
    int blank;    /* indicates blanks start */

    blank = 0;
    while ((c = getchar()) != EOF) {
        if (c != ' ') {
            putchar(c);
            blank = 0;
        }
        if (c == ' ')
            if (blank == 0) {
                putchar(c);
                blank = 1;
            }
    }
}


/* end of 1-09-1.c */
