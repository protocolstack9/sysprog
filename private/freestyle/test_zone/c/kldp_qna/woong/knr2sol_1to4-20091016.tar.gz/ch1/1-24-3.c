/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-24 (p.34): Write a program to check a C program for rudimentary syntax
 *              errors like unbalanced parentheses, brackets, braces. Don't
 *              forget about quotes, both single and double, escape sequences,
 *              and comments. (This program is hard if you do it in full
 *              generality.)
 *
 * As in the answer for 1-23, this answer assumes that the input code has
 * already been processed by a preprocessor and has no trigraphs.
 *
 * This solution assumes the sticky EOF, thus it may show strange behaviors when
 * that assumption is not satisfied. The sticky EOF is the mandatory behavior by
 * the Standard.
 */

#include <stdio.h>

int line = 1;

void comment(void)
{
    int c;

    while ((c = getchar()) != EOF) {
        if (c == '\n')
            line++;
        else if (c == '*') {
            c = getchar();
            if (c == '/')
                break;
            else
                ungetc(c, stdin);
        }
    }

    if (c == EOF)
        printf("program ends in a comment.\n");
}

void literal(int c)
{
    int q;

    q = c;
    while ((c = getchar()) != EOF && c != q) {
        if (c == '\n')
            line++;
        else if (c == '\\')
            if (getchar() == '\n')
                line++;
    }

    if (c == EOF)
        printf("program ends in a literal.\n");
}

void paren(int c)
{
    int p;
    int pline;

    p = c;
    pline = line;

    c = process();

    if (c == EOF)
        printf("unclosed %c on line %d.\n", p, pline);
    else if (!((p == '(' && c == ')') ||
               (p == '[' && c == ']') ||
               (p == '{' && c == '}')))
        printf("unbalanced %c on line %d.\n", c, line);
}

int process(void)
{
    int c;

    while ((c = getchar()) != EOF) {
        if (c == '\n')
            line++;
        else if (c == '/') {
            c = getchar();
            if (c == '*')
                comment();
            else
                ungetc(c, stdin);
        } else if (c == '\'' || c == '"')
            literal(c);
        else if (c == '(' || c == '[' || c == '{')
            paren(c);
        else if (c == ')' || c == ']' || c == '}')
            break;
    }

    return c;    /* EOF, or one of ), ] and } */
}

main()
{
    int c;

    while ((c = process()) != EOF)
        printf("unbalanced %c on line %d\n", c, line);

    return 0;
}


/* end of 1-24-3.c */
