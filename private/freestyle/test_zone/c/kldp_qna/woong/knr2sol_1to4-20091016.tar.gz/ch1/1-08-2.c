/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-8 (p.20): Write a program to count blanks, tabs, and newlines.
 *
 * This solution correctly handles an implementation where the last line is
 * allowed not to end with the newline character. Note that the last line with
 * no newline should be counted only when it contains any character; for example
 * the program should print "0 lines" for an empty file.
 *
 * Using if-else rather than consecutive if's can reduce the number of
 * comparsions.
 */

#include <stdio.h>

main()
{
    int c, lastc;
    int nb, nt, nl;

    nb = nt = nl = 0;
    lastc = '\n';    /* assigning '\n' to lastc precludes an empty file from
                        being considered to have a line */
    while ((c = getchar()) != EOF) {
        if (c == '\n')
            nl++;
        else if (c == '\t')
            nt++;
        else if (c == ' ')
            nb++;
        lastc = c;
    }
    if (lastc != '\n')
        nl++;

    printf("%d blanks, %d tabs, %d lines\n", nb, nt, nl);

    return 0;
}


/* end of 1-08-2.c */
