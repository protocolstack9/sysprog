/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-12
 *
 * 1-14 (p.24): Write a program to print a histogram of the frequencies of
 *              different characters in its input.
 *
 * Since unsigned integer types are not introduced yet, only characters whose
 * values range from 0 to 127 are counted correctly; other characters are put
 * into the group named "OV".
 */

#include <stdio.h>

#define MAX_FREQ 128    /* number of different characters */
#define MAX_BAR  50     /* max length of bar in histogram */

main()
{
    int c;
    int i, max, freq[MAX_FREQ+1];

    for (i = 0; i <= MAX_FREQ; ++i)
        freq[i] = 0;

    while ((c = getchar()) != EOF) {
        if (c >= 0 && c < MAX_FREQ)
            freq[c]++;
        else
            freq[MAX_FREQ]++;
    }

    max = 0;
    for (i = 0; i <= MAX_FREQ; ++i)
        if (max < freq[i])
            max = freq[i];

    for (i = 0; i <= MAX_FREQ; ++i)
        if (freq[i]) {
            if (i < MAX_FREQ)
                printf("%3d (%4d): ", i, freq[i]);
            else
                printf(" OV (%4d): ", freq[i]);
            freq[i] = freq[i] * MAX_BAR / max;
            if (freq[i] == 0)
                freq[i] = 1;
            while (freq[i]-- > 0)
                putchar('*');
            putchar('\n');
        }
}


/* end of 1-14.c */
