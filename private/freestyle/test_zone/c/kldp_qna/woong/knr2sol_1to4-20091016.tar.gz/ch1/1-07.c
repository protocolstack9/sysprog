/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-7 (p.17): Write the program to print the value of EOF.
 */

#include <stdio.h>

main()
{
    printf("The value of EOF is %d\n", EOF);
}


/* end of 1-07.c */
