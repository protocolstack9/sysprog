/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-12 (p.21): Write a program that prints its input one word per line.
 */

#include <stdio.h>

main()
{
    int c;
    int blank;    /* indicates blanks start */

    blank = 0;
    while ((c = getchar()) != EOF) {
        if (c == ' ' || c == '\t' || c == '\n') {
            if (blank == 0) {
                blank = 1;
                putchar('\n');
            }
        } else {
            blank = 0;
            putchar(c);
        }
    }
}


/* end of 1-12.c */
