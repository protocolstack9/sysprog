/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-13
 *
 * 1-19 (p.31): Write a funciotn reverse(s) that reverses the character string
 *              s. Use it to write a program that reverses its input a line at a
 *              time.
 *
 * With no dynamic storage allocation, it is not avoiable to impose some limit
 * on the max. length of a line. Thus, a line longer than MAX_LINE results in
 * multiple separate lines, each of which has its own newline character.
 *
 * For the modification on getline() below, see 1-16.c.
 */

#include <stdio.h>

#define MAX_LINE 80    /* maximum input line length */

int getline(char line[], int maxline);
void reverse(char s[]);

main()
{
    int n;
    char line[MAX_LINE];

    while ((n = getline(line, MAX_LINE)) > 0) {
        if (line[n-1] == '\n')
            line[n-1] = '\0';
        reverse(line);
        printf("%s\n", line);
    }

    return 0;
}

void reverse(char s[])
{
    int t;
    int i, j;

    j = 0;
    while (s[j] != '\0')
        ++j;
    j--;    /* index of last (non-null) character */

    i = 0;
    while (i < j) {
        t = s[j];
        s[j] = s[i];
        s[i] = t;
        ++i;
        j--;
    }
}

int getline(char s[], int lim)
{
    int c, i;

    for (i = 0; i < lim-1 && ((c = getchar()) != EOF && c != '\n'); ++i)
        s[i] = c;

    if (c == '\n') {
        s[i] = c;
        ++i;
    } else if (c == EOF) {    /* for the last line with no newline */
        if (i > 0) {
            s[i] = '\n';
            ++i;
        }
    } else {
        /* if the buffer is full and the next call to getchar() gives EOF, the
           next call to getline() will return 0 rather than correctly compensate
           the missing newline; this modification is for such a case */
        c = getchar();
        ungetc((c == EOF)? '\n': c, stdin);
    }
    s[i] = '\0';

    return i;
}


/* end of 1-19.c */
