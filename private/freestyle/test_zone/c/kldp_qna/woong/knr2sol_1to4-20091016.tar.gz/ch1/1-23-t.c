/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-23 (p.34): Write a program to remove all comments from a C program. Don't
 *              forget to handle quoted strings and character constants
 *              properly, C comments do not nest.
 *
 * This code was used when testing various solutions for Exercise 1-23. By
 * giving this code itself to the solutions, it can be checked how well they
 * work with the lines commented out by #if 0. Also, this code tries to produce
 * several test files that all end with no newline. Those files can be used to
 * see how well the solutions handle exception cases in an implementation where
 * files are allowed to end without the newline character.
 */

#if 0
    foo//bar
    foo/**bar*bar*/bar
    //***/
    foo/bar
    foo/'bar'
    foo "/*" bar
    foo "*/" bar
    foo "/" bar
    foo '/*' bar
    foo '*/' bar
    foo '/' bar
    foo '\'' bar
    foo '"' bar
    foo "'" bar
    foo "\"" bar
    foo '/' bar
    foo "/" bar
    foo '*' bar
    foo "*" bar
#endif

#include <assert.h>
#include <stdio.h>

int main(void)
{
    FILE *fp;

    fp = fopen("test1.txt", "w");
    assert(fp);
    fprintf(fp, "foo'bar");
    fclose(fp);

    fp = fopen("test2.txt", "w");
    assert(fp);
    fprintf(fp, "foo\"bar");
    fclose(fp);

    fp = fopen("test3.txt", "w");
    assert(fp);
    fprintf(fp, "foo'bar\\");
    fclose(fp);

    fp = fopen("test4.txt", "w");
    assert(fp);
    fprintf(fp, "foo\"bar\\");
    fclose(fp);

    fp = fopen("test5.txt", "w");
    assert(fp);
    fprintf(fp, "foo /");
    fclose(fp);

    fp = fopen("test6.txt", "w");
    assert(fp);
    fprintf(fp, "foo /*");
    fclose(fp);

    fp = fopen("test7.txt", "w");
    assert(fp);
    fprintf(fp, "foo /* bar *");
    fclose(fp);

    return 0;
}


/* end of 1-23-t.c */
