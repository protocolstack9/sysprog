/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-24 (p.34): Write a program to check a C program for rudimentary syntax
 *              errors like unbalanced parentheses, brackets, braces. Don't
 *              forget about quotes, both single and double, escape sequences,
 *              and comments. (This program is hard if you do it in full
 *              generality.)
 *
 * As in the answer for 1-23, this answer assumes that the input code has
 * already been processed by a preprocessor and has no trigraphs.
 *
 * Besides declaring a stack of the limited size, recursive calls provide an
 * implicit stack maintained by an implementation.
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#define PROGRAM  0
#define COMMENT  1
#define LITERAL  2

#define MAX_STACK 1024

main()
{
    int state;
    int c, q;
    int lineno;
    struct {
        int top;
        int ch[MAX_STACK];
        int line[MAX_STACK];
    } stack;

    lineno = 1;
    state = PROGRAM;
    while ((c = getchar()) != EOF) {
        switch(state) {
            case PROGRAM:
                if (c == '\n')
                    lineno++;
                else if (c == '/') {
                    c = getchar();
                    if (c == '*')
                        state = COMMENT;
                    else
                        ungetc(c, stdin);
                } else if (c == '\'' || c == '"') {
                    q = c;
                    state = LITERAL;
                } else if (c == '(' || c == '[' || c == '{') {
                    if (stack.top < MAX_STACK) {    /* push */
                        stack.ch[stack.top] = c;
                        stack.line[stack.top++] = lineno;
                    } else {
                        printf("stack overflow.\n");
                        return EXIT_FAILURE;
                    }
                } else if (c == ')' || c == ']' || c == '}') {
                    if (stack.top == 0)
                        printf("unbalanced %c on line %d.\n", c, lineno);
                    else {    /* pop */
                        stack.top--;
                        if (!((c == ')' && stack.ch[stack.top] == '(') ||
                              (c == ']' && stack.ch[stack.top] == '[') ||
                              (c == '}' && stack.ch[stack.top] == '{')))
                            printf("unbalanced %c on line %d.\n", c, lineno);
                    }
                }
                break;
            case COMMENT:
                if (c == '*') {
                    c = getchar();
                    if (c == '/')
                        state = PROGRAM;
                    else
                        ungetc(c, stdin);
                }
                break;
            case LITERAL:
                if (c == '\\') {
                    if (getchar())
                        lineno++;
                } else if (c == q)
                    state = PROGRAM;
                break;
            default:
                assert(!"invalid state -- should never reach here");
                break;
        }
    }

    while (stack.top-- > 0)
        printf("unclosed %c on line %d\n", stack.ch[stack.top],
               stack.line[stack.top]);

    if (state == COMMENT)
        printf("program ends in a comment.\n");
    else if (state == LITERAL)
        printf("program ends in a string/character literal.\n");

    return 0;
}


/* end of 1-24-2.c */
