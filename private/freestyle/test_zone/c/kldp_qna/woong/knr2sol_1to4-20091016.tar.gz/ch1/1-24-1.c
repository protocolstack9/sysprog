/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-12
 *
 * 1-24 (p.34): Write a program to check a C program for rudimentary syntax
 *              errors like unbalanced parentheses, brackets, braces. Don't
 *              forget about quotes, both single and double, escape sequences,
 *              and comments. (This program is hard if you do it in full
 *              generality.)
 *
 * As in the answer for 1-23, this answer assumes that the input code has
 * already been processed by a preprocessor and has no trigraphs.
 *
 * The answer can be improved by using ungetc() and the switch statement. Also,
 * this is a good example for introducing the structure type.
 */

#include <stdio.h>

#define PROGRAM  0
#define STARTCMT 1
#define COMMENT  2
#define ENDCMT   3
#define LITERAL  4

#define MAX_STACK 10

main()
{
    int state;
    int overflow;
    int c, q;
    int top;
    int stack[MAX_STACK];
    int line[MAX_STACK], lineno;

    overflow = 0;
    lineno = 1;
    state = PROGRAM;
    while (!overflow && (c = getchar()) != EOF) {
        if (state == PROGRAM) {
            if (c == '\n')
                ++lineno;
            else if (c == '/')
                state = STARTCMT;
            else if (c == '\'' || c == '"') {
                q = c;
                state = LITERAL;
            } else if (c == '(' || c == '[' || c == '{') {
                if (top < MAX_STACK) {    /* push */
                    stack[top] = c;
                    line[top] = lineno;
                    ++top;
                } else {
                    printf("stack overflow.\n");
                    overflow = 1;
                }
            } else if (c == ')' || c == ']' || c == '}') {
                if (top == 0)
                     printf("unbalanced %c on line %d.\n", c, lineno);
                else {    /* pop */
                    top--;
                    if (!((c == ')' && stack[top] == '(') ||
                          (c == ']' && stack[top] == '[') ||
                          (c == '}' && stack[top] == '{')))
                        printf("unbalanced %c on line %d.\n", c, lineno);
                }
            }
        } else if (state == STARTCMT) {
            if (c == '*')
                state = COMMENT;
            else if (c == '\'' || c == '"') {
                q = c;
                state = LITERAL;
            } else if (c != '/')
                state = PROGRAM;
        } else if (state == COMMENT) {
            if (c == '*')
                state = ENDCMT;
        } else if (state == ENDCMT) {
            if (c == '/')
                state = PROGRAM;
            else if (c != '*')
                state = COMMENT;
        } else if (state == LITERAL) {
            if (c == '\\') {
                if (getchar() == '\n')
                    ++lineno;
            } else if (c == q)
                state = PROGRAM;
        }
    }

    if (!overflow) {
        while (top > 0) {
            top--;
            printf("unclosed %c on line %d\n", stack[top], line[top]);
        }
    }

    if (state == STARTCMT || state == COMMENT || state == ENDCMT)
        printf("program ends in a comment.\n");
    else if (state == LITERAL)
        printf("program ends in a string/character literal.\n");

    return 0;
}


/* end of 1-24-1.c */
