/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-13
 *
 * 1-22 (p.34): Write a program to "fold" long input lines into two or more
 *              shorter lines after the last non-blank character that occurs
 *              before the n-th column of input. Make sure your program does
 *              something intelligent with very long lines, and if there are no
 *              blanks or tabs before the specified column.
 *
 * This solution tries to preserve spaces in the input; for example, preceding
 * or trailing blanks are printed out untouched, and spaces resulted from
 * expanding a tab are dealt with in the same way. Thus, getting folded lines
 * back to one by splicing them recovers the original form.
 *
 * Expanding tabs to spaces properly (especially handling a tab whose expansion
 * results in spaces spanning over a line boundary) makes code very complicated.
 * Using a static variable and a precision for %s can highly improve code's
 * readability.
 */

#include <stdio.h>

#define MAX_LINE 80    /* number of chars in a line */
#define TAB_STOP 8

int foldpos(char s[], int len);

main()
{
    int c;
    char s[MAX_LINE+2];    /* MAX_LINE + newline + null */
    int max,
        cnt,      /* number of accumulated chars in a line */
        space,    /* number of spaces from tab expansion */
        idx;      /* index to store a char to s */
    int i, pos;

    c = 0;
    cnt = 0;
    idx = 0;
    space = 0;
    max = MAX_LINE+2;

    while (c != EOF) {
        while (space > 0 && idx < max-1) {    /* for spanning-over spaces */
            s[idx] = ' ';
            ++idx;
            ++cnt;
            space--;
        }
        c = ' ';    /* as if last char read is blank */

        while (idx < max-1 && (c = getchar()) != EOF && c != '\n') {
            if (c == '\t') {    /* expands a tab */
                space = TAB_STOP - (cnt % TAB_STOP);
                while (space > 0 && idx < max-1) {
                    s[idx] = ' ';
                    ++idx;
                    ++cnt;
                    space--;
                }
            } else {
                s[idx] = c;
                ++idx;
                ++cnt;
            }
        }
        if (c == '\n') {
            s[idx] = c;
            ++idx;
            cnt = 0;
        } else if (c == EOF && cnt > 0) {    /* for the last line with no newline */
            /* no need to use ungetc() (see 1-16.c) because of using cnt in
               condition expression instead of idx */
            s[idx] = '\n';
            ++idx;
            cnt = 0;
        }
        s[idx] = 0;

        if (idx > 0) {
            if (s[idx-1] != '\n') {    /* long line, so fold */
                pos = foldpos(s, idx);
                for (i = 0; i <= pos; ++i)
                    putchar(s[i]);
                putchar('\n');
                while (i < idx) {
                    putchar(s[i]);
                    ++i;
                }
            } else {
                printf("%s", s);
                pos = idx - 1;
            }
            max = MAX_LINE - (idx-pos-1) + 2;
            idx = 0;
        }
    }

    return 0;
}

int foldpos(char s[], int len)
{
    int j;

    len--;    /* backs off null char */
    len--;    /* backs off last extra char */

    /* note that len can be -1 here when s[] carries only the extra char (this
       occurs when a line containing a space and at least MAX_LINE following
       non-space chars given, or when MAX_LINE is 1); it works well, however,
       even if foldpos() returns -1 */

    j = len;
    while (j >= 0 && s[j] != ' ')
        j--;

    if (j < 0)    /* no space, thus forcibly fold */
        j = len;

    return j;
}


/* end of 1-22-1.c */
