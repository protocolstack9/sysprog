/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-13A (p.24): Write a program to print a histogram of the lengths of words in
 *               its input. It is easy to draw the histogram with the bars
 *               horizontal;
 *
 * This answer differs from 1-13-a-1.c in two points:
 * - it counts the number of words longer than MAX_LEN and prints the count;
 * - it limits the max. length of bars in the resulting histogram by using
 *   ratios; the max. length of bars is determined by MAX_HIST.
 */

#include <stdio.h>

#define MAX_HIST 15    /* max length of histogram */
#define MAX_LEN  15    /* max length of word */

main()
{
    int c;
    int i, len, store_len[MAX_LEN+1], max;
    int blank;    /* indicates blanks start */

    for (i = 0; i <= MAX_LEN; i++)
        store_len[i] = 0;

    len = 0;
    blank = 0;
    while ((c = getchar()) != EOF) {
        if (c == ' ' || c == '\n' || c == '\t') {
            if (!blank) {    /* end of word */
                if (len-1 < MAX_LEN)
                    store_len[len-1]++;
                else
                    store_len[MAX_LEN]++;
            }
            blank = 1;
        } else if (blank) {    /* beginning of word */
            blank = 0;
            len = 1;
        } else
            len++;       /* inside word */
    }

    max = 0;
    for (i = 0; i <= MAX_LEN; i++)
        if (max < store_len[i])
            max = store_len[i];

    for (i = 0; i <= MAX_LEN; i++)
        if (store_len[i]) {
            if (i < MAX_LEN)
                printf("%3d-char (%4d): ", i+1, store_len[i]);
            else
                printf(" OV-char (%4d): ", store_len[i]);
            len = store_len[i] * MAX_HIST / max;
            if (len == 0)
                len = 1;
            while (len-- > 0)
                putchar('*');
            putchar('\n');
        }

    return 0;
}


/* end of 1-13-a-2.c */
