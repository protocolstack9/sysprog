/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-12
 *
 * 1-21 (p.34): Write a program "entab" that replaces strings of blanks by the
 *              minimum number of tabs and blanks to achieve the same spacing.
 *              Use the same tab stops as for "detab". When either a tab or a
 *              single blank would suffice to reach a tab stop, which should be
 *              given preference?
 *
 * To answer the question, a tab is preferred in this answer since we can avoid
 * handling a special case; emitting a blank when either a tab or a blank would
 * suffice to get the same result requires an additional check for that case
 * here.
 */

#include <stdio.h>

#define TAB_STOP 8

main()
{
    int c;
    int cnt,    /* number of accumulated chars in a line */
        bn;     /* number of consecutive blanks */

    bn = 0;
    cnt = 0;
    while ((c = getchar()) != EOF) {
        ++cnt;
        if (c == ' ') {
            if (cnt % TAB_STOP == 0) {
                bn = 0;
                putchar('\t');
            } else
                ++bn;
        } else if (c == '\t') {
            bn = 0;
            cnt = cnt + (TAB_STOP - cnt % TAB_STOP);
            putchar(c);
        } else {
            while (bn > 0) {
                putchar(' ');
                bn--;
            }
            if (c == '\n')
                cnt = 0;
            putchar(c);
        }
    }

    return 0;
}


/* end of 1-21.c */
