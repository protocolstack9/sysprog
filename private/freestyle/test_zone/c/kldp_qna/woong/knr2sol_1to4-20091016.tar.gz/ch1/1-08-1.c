/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-12
 *
 * 1-8 (p.20): Write a program to count blanks, tabs, and newlines.
 *
 * This solution may show an incorrect result on an implementation where the
 * last line is allowed not end with the newline character.
 *
 * Using if-else rather than consecutive if's can reduce the number of
 * comparsions.
 */

#include <stdio.h>

main()
{
    int c
    int nb, nt, nl;

    nb = nt = nl = 0;
    while ((c = getchar()) != EOF) {
        if (c == '\n')
            ++nl;
        if (c == '\t')
            ++nt;
        if (c == ' ')
            ++nb;
    }
    printf("%d blanks, %d tabs, %d lines\n", nb, nt, nl);
}


/* end of 1-08-1.c */
