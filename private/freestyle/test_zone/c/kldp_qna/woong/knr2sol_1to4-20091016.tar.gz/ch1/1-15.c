/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-15 (p.27): Rewrite the temperature conversion program of Section 1.2 to use
 *              a function for conversion.
 */

#include <stdio.h>

float fahr_to_cel(float fahr)
{
    return (5.0 / 9.0) * (fahr - 32);
}

main()
{
    float fahr;
    int lower, upper, step;

    lower = 0;      /* lower limit of temperature table */
    upper = 300;    /* upper limit */
    step = 20;      /* step size */

    fahr = lower;
    while (fahr <= upper) {
        printf("%3.0f %6.1f\n", fahr, fahr_to_cel(fahr));
        fahr = fahr + step;
    }

    return 0;
}


/* end of 1-15.c */
