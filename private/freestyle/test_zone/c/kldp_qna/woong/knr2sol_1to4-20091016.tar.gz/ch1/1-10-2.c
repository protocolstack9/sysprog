/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-10 (p.20): Write a program to copy its input to its output, replacing each
 *              tab by \t, each backspace by \b, and each backslash by \\. This
 *              makes tabs and backspaces visible in an unambiguous way.
 */

#include <stdio.h>

main()
{
    int c;

    while ((c = getchar()) != EOF) {
        switch(c) {
            case '\t':
                printf("\\t");
                break;
            case '\b':
                printf("\\b");
                break;
            case '\\':
                printf("\\\\");
                break;
            default:
                putchar(c);
                break;
        }
    }

    return 0;
}


/* end of 1-10-2.c */
