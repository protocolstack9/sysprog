/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-12
 *
 * 1-20 (p.34): Write a program "detab" that replaces tabs in the input with the
 *              proper number of blanks to space th the next tab stop. Assume a
 *              fixed set of tab stops, say every n columns. Should n be a
 *              varaiable or a symbolic parameter?
 *
 * To do answer the question, in this program, n is a symbolic constant. Making
 * it a variable, however, enables accepting the tab stop as a program argument
 * even if it still remains constant.
 */

#include <stdio.h>

#define TAB_STOP 4    /* tab stop size */

main()
{
    int c;
    int i, cnt;

    cnt = 0;
    while ((c = getchar()) != EOF) {
        if (c == '\t') {
            i = TAB_STOP - (cnt % TAB_STOP);
            while (i > 0) {
                putchar(' ');
                ++cnt;
                i--;
            }
        } else if (c == '\n') {
            putchar(c);
            cnt = 0;
        } else {
            putchar(c);
            ++cnt;
        }
     }

     return 0;
}


/* end of 1-20.c */
