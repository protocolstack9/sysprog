/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 1-9 (p.20): Write a program to copy its input to its output, replacing each
 *             string of one or more blanks by a single blank.
 */

#include <stdio.h>

main()
{
    int c,
        pc;    /* previous character */

    pc = EOF;
    while ((c = getchar()) != EOF) {
        if (c != ' ' || pc != ' ')
            putchar(c);
        pc = c;
    }

    return 0;
}


/* end of 1-09-2.c */
