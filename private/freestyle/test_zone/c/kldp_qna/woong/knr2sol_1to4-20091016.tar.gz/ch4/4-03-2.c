/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 4-3 (p.79): Given the basic framework, it's straightforward to extend the
 *             calculator. Add the modulus (%) operator and provisions for
 *             negative numbers.
 *
 * The solution given here is intended to minimally modify the existing
 * calculator code in the text. To run this, you should copy the omitted parts
 * from the text.
 *
 * Some points to note are:
 * - In order to use fmod(), <math.h> is #included and it might be required to
 *   manually link a math library, e.g., with an option -lm.
 * - Note that, in the modification to getop(), a minus is already in s[0] when
 *   a digit or period is found after the minus.
 * - ungetch(), unlike ungetc() provided in <stdio.h>, cannot handle EOF, thus a
 *   check against EOF is necessary before calling it.
 * - In the original code given in the text, s[i] and c are assumed to contain a
 *   digit or period at "point A." There are at least two equivalent ways to
 *   meet that assumption:
 *   (1) push back the character looked ahead, store '-' into c and revise the
 *       expression in the if statement below "point A" to include "|| c == '-'"
 *       in which case assigning the pushed-back character to s[] is done by the
 *       first while statement. (implemented in 4-03-1.c)
 *   (2) store c into s[++i], which has the equivalent status to when the first
 *       if statement and the following assignment were executed in the original
 *       code except for the value of i.
 */

#include <math.h>      /* added for fmod() */
#include <stdio.h>
#include <stdlib.h>

#define MAXOP 100
#define NUMBER '0'

int getop(char []);
void push(double);
double pop(void);

main()
{
    int type;
    double op2;
    char s[MAXOP];

    while ((type = getop(s)) != EOF) {
        switch(type) {
            /* case labels from NUMBER to '/' omitted */

            /* start of code to handle % */
            case '%':
                op2 = pop();
                if (op2 != 0.0)
                    push(fmod(pop(), op2));
                else
                    printf("error: zero divisor\n");
                break;
            /* end of code to handle % */

            /* case labels for '\n' and default label omitted */
        }
    }

    return 0;
}

/* push(), pop() and their relevant macros and variables omitted */

#include <ctype.h>

int getch(void);
void ungetch(int);

int getop(char s[])
{
    int i, c;

    while ((s[0] = c = getch()) == ' ' || c == '\t')
        ;
    s[1] = '\0';
    if (!isdigit(c) && c != '.' && c != '-')
        return c;
    i = 0;

    /* start of code to handle negative numbers */
    if (c == '-') {    /* probably a number */
        c = getch();
        if (isdigit(c) || c == '.')
            s[++i] = c;
        else {
            if (c != EOF)
                ungetch(c);
            return '-';
        }
    }
    /* end of code to handle negative numbers */
    /* point A */

    if (isdigit(c))
        while (isdigit(s[++i] = c = getch()))
            ;
    if (c == '.')
        while (isdigit(s[++i] = c = getch()))
            ;
    s[i] = '\0';
    if (c != EOF)
        ungetch(c);

    return NUMBER;
}

/* getch(), ungetch() and their relevant macros and variables omitted */


/* end of 4-03-2.c */
