/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-06
 *
 * 4-8 (p.79): Suppose there will never be more than one character of pushback.
 *             Modify getch and ungetch accordingly.
 *
 * Letting the pushback buffer contain any character that the char type can
 * represent requires an additional flag to indicate if the buffer has a
 * character.
 *
 * There is another way for the flag by changing the type of buf to int,
 * which is supposed to represent more values than char does.
 */

#include <stdio.h>

#include <ctype.h>

char buf;
int buff;

int getch(void)
{
    return (buff)? (buff = 0, buf): getchar();
}

void ungetch(int c)
{
    if (buff)
        printf("ungetch: too many characters\n");
    else {
        buff = 1;
        buf = c;
    }
}

main()
{
    int c;

    while ((c = getch()) != EOF) {
        if (isdigit(c) && (c-'0') % 2 == 0)
            ungetch(++c);
        else
            putchar(c);
    }

    return 0;
}


/* end of 4-08-1.c */
