/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 4-2 (p.73): Extend atof to handle scientific notation of the form
 *                 123.45e-6
 *             where a floating-point number may be followed by e or E and an
 *             optionally signed exponent.
 *
 * This solution differs from the former solution in that:
 * - division by 10 is used instead of multiplication by 0.1 when a negative
 *   exponent is given, which is likely to be better in accuracy; remember,
 *   however, that repeatedly applying floating-point operations inevitably
 *   results in inaccuracy;
 * - before applying an exponent, this solution calculates the intermediate
 *   result and thus avoids the premature overflow, which means it causes no
 *   overflow if neither atof() given in K&R2 nor the final result does; and
 * - this solution replaces every array indexing with an equivalent pointer
 *   operation.
 *
 * There are some possible chances to check over/underflow:
 * - when accumulating an exponent from a string representation and
 * - when applying an exponent to a calculated value.
 *
 * Note that ove/underflow check before applying an exponent may be
 * meaningless. For example, suppose that 10 powered to 9 causes overflow.
 * 1000000000 results in overflow while 1000000000e-9 should not.
 *
 * See the references mentioned in the former solution for how difficult
 * the base conversion is.
 *
 * For test this solution #includes <stdlib.h> which defines atof(). Thus, the
 * function name is changed to myatof().
 */

#include <ctype.h>

#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

double myatof(char s[])
{
    double val, power;
    int sign;

    while (isspace(*s))
        s++;
    sign = (*s == '-')? -1: 1;
    if (*s == '+' || *s == '-')
        s++;
    for (val = 0.0; isdigit(*s); s++)
        val = 10.0 * val + (*s - '0');
    if (*s == '.')
        s++;
    for (power = 1.0; isdigit(*s); s++) {
        val = 10.0 * val + (*s - '0');
        power *= 10;
    }

    val = sign * val / power;

    if (*s == 'e' || *s == 'E') {
        int e;

        sign = (*++s == '-')? -1: 1;
        if (*s == '+' || *s == '-')
            s++;
        for (e = 0; isdigit(*s); s++)
            e = 10 * e + (*s - '0');
        while (e-- > 0)
            if (sign > 0)
                val *= 10;
            else
                val /= 10;
    }

    return val;
}

main()
{
    int i, e;
    double n;
    time_t t;
    unsigned seed;
    const char *sign[] = { "", "+", "-" };
    char buf[sizeof("0.12345e+37")], buf2[sizeof(buf)], *endp;

    t = time(NULL);
    assert(t != (time_t)-1);

    /* gets seed from time() */
    seed = 0;
    for (i = 0; i < sizeof(t); i++)
        seed += ((unsigned char *)&t)[i];
    srand(seed);

    for (i = 0; i < 10; i++) {
        n = (double)rand() / RAND_MAX;           /* [0, 1] */
        e = ((double)rand() / RAND_MAX) * 37;    /* [0, 37] */
        sprintf(buf, "%.5f%c%s%d", n, ((e % 2)? 'e': 'E'), sign[e % 3], e);
        errno = 0;
        n = strtod(buf, &endp);
        assert(errno == 0 && *endp == '\0');

        sprintf(buf2, "%.5e", myatof(buf));
        sprintf(buf, "%.5e", n);

        printf("myatof() gives %s for %s", buf2, buf);
        if (strcmp(buf, buf2) == 0)
            putchar('\n');
        else
            printf(" - different (but may not be wrong)\n");
    }

    return 0;
}


/* end of 4-02-2.c */
