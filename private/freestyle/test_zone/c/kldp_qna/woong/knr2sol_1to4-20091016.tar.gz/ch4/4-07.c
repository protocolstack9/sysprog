/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-29
 *
 * 4-7 (p.79): Write a routine ungets(s) that will push back an entire string
 *             onto the input. Should ungets know about buf and bufp, or should
 *             it just use ungetch?
 *
 * ungets() does not need to directly access to buf or bufp, and can be
 * implemented on ungetch(). This has a great advantage that the mechanism on
 * which getch() and ungetch() are based can be separated from ungets(). Note
 * that, however, ungetch() does its job on a stack, which means ungets() pushes
 * the last character in a string first and the first character last.
 *
 * As always, a pointer-arithmetic version (as opposed to an array-indexing
 * version) is possible, but due to the backward loop on a string, its merit
 * vanashes.
 */

#include <stdio.h>

#define BUFSIZE 100

char buf[BUFSIZE];
int bufp = 0;

int getch(void)
{
    return (bufp > 0)? buf[--bufp]: getchar();
}

void ungetch(int c)
{
    if (bufp >= BUFSIZE)
        printf("ungetch: too many characters\n");
    else
        buf[bufp++] = c;
}

void ungets(char s[])
{
    int i;

    for (i = 0; s[i] != '\0'; i++)
        ;
    while (i-- > 0)
        ungetch(s[i]);
}

main()
{
    int c, i;
    char test[] = "Test Message";

    ungets(test);

    for (i = 0; i < sizeof(test)-1; i++)
        if ((c = getch()) != test[i])
            printf("failed; %c should be %c\n", c, test[i]);

    return 0;
}


/* end of 4-07.c */
