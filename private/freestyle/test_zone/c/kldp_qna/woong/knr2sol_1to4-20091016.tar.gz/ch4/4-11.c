/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-13
 *
 * 4-11 (p.83): Modify getop so that it doesn't need to use ungetch. Hint: use
 *              an internal static variable.
 *
 * The solution given here is intended to minimally modify the existing
 * calculator code in the answer to 4-6. To run this, you should copy the
 * omitted parts from the text and the answer.
 *
 * If ungetch() gets unnecessary, getch() can be replaced with a direct call to
 * getchar(). Whenever getchar() is used, it should be considered if a
 * pushed-back character should be delievered instead of getting a new one with
 * getchar(). Fortunately, in every place where unreading a character, getop()
 * returns immediately. Thus, a push-back character needs to be considered only
 * at the entry of getop(). Note that when pushing a character back, it is not
 * checked for EOF since EOF in pushback signals no character pushed back and,
 * due to sticky EOF, a call to getchar() returns EOF again.
 */

#include <assert.h>
#include <errno.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

/* main() and its relevant macros omitted */

/* index(), setvar(), push(), pop(), pusht(), popt(), clear() and their relevant
   macros and variables omitted */

#include <ctype.h>

/* declarations for getch() and ungetch() removed */

int getop(char s[])
{
    static int pushback = EOF;

    int i, c;

    if (pushback == EOF)
        c = getchar();
    else {
        c = pushback;
        pushback = EOF;
    }
    while ((s[0] = c) == ' ' || c == '\t')
        c = getchar();
    s[1] = '\0';

    /* zero pushed-back char guaranteed */

    i = 0;
    if (isalpha(c)) {
        while (isalpha(s[++i] = c = getchar()))
            ;
        s[i] = 0;
        pushback = c;    /* push back and return */
        return NAME;
    }

    if (!isdigit(c) && c != '.' && c != '-')
        return c;

    if (c == '-') {
        c = getchar();
        if (isdigit(c) || c == '.')
            s[++i] = c;
        else {
            pushback = c;    /* push back and return */
            return '-';
        }
    }

    if (isdigit(c))
        while (isdigit(s[++i] = c = getchar()))
            ;
    if (c == '.')
        while (isdigit(s[++i] = c = getchar()))
            ;
    s[i] = '\0';
    pushback = c;    /* push back and return */

    return NUMBER;
}

/* getch() and ungetch() are no longer necessary */


/* end of 4-11.c */
