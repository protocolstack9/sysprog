/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-15
 *
 * 4-14 (p.91): Define a macro swap(t,x,y) that interchanges two arguments of
 *              type t. (Block structure will help.)
 *
 * There is no way to implement a swap macro that is guaranteed to always work.
 * See 4-14-1.c for detailed explanation.
 *
 * The "do { ... } while(0)" construct does not have problems the former two
 * solutions exhibit and is the most widely used trick for a macro containing
 * block structure.
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define swap(t,x,y) do { t _t; _t = x; x = y; y = _t; } while(0)

main()
{
    int i;
    time_t t;
    int i1, i2;
    double d1, d2;
    void *p1, *p2;
    unsigned seed;

    t = time(NULL);
    assert(t != (time_t)-1);

    /* gets seed from time() */
    seed = 0;
    for (i = 0; i < sizeof(t); i++)
        seed += ((unsigned char *)&t)[i];
    srand(seed);

    i1 = ((double)rand() / RAND_MAX) * 100;    /* [0, 100] */
    i2 = ((double)rand() / RAND_MAX) * 100;    /* [0, 100] */

    d1 = (double)rand() / RAND_MAX;    /* [0, 1] */
    d2 = (double)rand() / RAND_MAX;    /* [0, 1] */

    p1 = &i1;
    p2 = &d2;

    printf("before: %d, %d\n", i1, i2);
    swap(int, i1, i2);
    printf("after: %d, %d\n", i1, i2);

    printf("before: %f, %f\n", d1, d2);
    swap(double, d1, d2);
    printf("after: %f, %f\n", d1, d2);

    printf("before: %p, %p\n", p1, p2);
    swap(void *, p1, p2);
    printf("after: %p, %p\n", p1, p2);

    return 0;
}


/* end of 4-14-3.c */
