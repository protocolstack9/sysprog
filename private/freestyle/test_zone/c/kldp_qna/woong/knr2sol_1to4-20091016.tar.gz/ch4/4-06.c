/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-28
 *
 * 4-6 (p.79): Add commands for handling variables. (It's easy to provide
 *             twenty-six variables with single-letter names.) Add a variable
 *             for the most recently printed value.
 *
 * The solution given here is intended to minimally modify the existing
 * calculator code in the answer to 4-5. To run this, you should copy the
 * omitted parts from the text and the answer.
 *
 * Only single-character variables from 'a' to 'z' and 'Z' for the last printed
 * value are supported. To support them in a more complete way [*], another
 * stack is introduced to keep the type of values; if the type is not NUMBER,
 * the type represents the name of a variable that can be used as an index to an
 * array for variables.
 *
 * Modifications from the answer to the previous problem include:
 * - FUNCTION is renamed to NAME because a sequence of alphabetical characters
 *   designates not only a math function but a variable;
 * - a new command, = is introduced to assign a value to a variable. the command
 *   assigns a value to a variable and pushes the assigned value to the stack;
 * - index() is introduced to obtain an array index from a variable name;
 * - setvar() is introduced to set a variable to a value (setvar() is for aiding
 *   modularization of those stack-related functions);
 * - push() is modified to put NUMBER into the type stack when doing a value to
 *   the value stack;
 * - pop() is modified to obtain a value stored in a variable when the type of
 *   the top element is not NUMBER;
 * - pusht() is introduced to put a variable name to the type stack;
 * - popt() is introduced to obtain a variable name from the type stack when a
 *   variable is referenced in an expression;
 * - assertions are introduced, whose elimination does and should have no effect
 *   on the program's behavior.
 *
 * When a variable is evaluated by a command (except =), the variable is
 * converted to its stored value. To be precise,
 * - # prints the value of a variable if an operand is a variable, and pushes
 *   the value (not the variable) to the stack;
 * - & duplicates the value of a variable (not a variable designation) if an
 *   operand is a variable; and
 * - ^ also converts a variable to its stored value when either operand is a
 *   variable.
 *
 * Expanding the stack in the way hired here provides a good example for using
 * a structure, but introducing it without redesign of the program would make
 * the code clumsy.
 *
 * [*] It is possible to avoid introducing another stack for types by requiring
 *     a variable follow an expression whose result goes to the variable and
 *     precede the equal sign as in "1 2 + x =" to specify "assigning the result
 *     of 1+2 to x" In such a case, only the latest accessed variable needs to
 *     be remembered.
 */

#include <assert.h>    /* added for assert() */
#include <errno.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#define MAXOP 100
#define NUMBER '0'
#define NAME '1'    /* FUNCTION renamed to NAME */

int getop(char []);
void push(double);
double pop(void);
void clear(void);

/* start of declarations for functions to handle variables */
int index(int);
int setvar(int, double);
void pusht(int);
int popt(void);
/* end of declarations for functions to handle variables */

main()
{
    int type;
    double op2;
    char s[MAXOP];

    while ((type = getop(s)) != EOF) {
        switch(type) {
            /* case labels from NUMBER to '!' omitted */

            /* start of code to handle variables */
            case NAME:
                errno = 0;
                if (strcmp(s, "sin") == 0)
                    push(sin(pop()));
                else if (strcmp(s, "cos") == 0)
                    push(cos(pop()));
                else if (strcmp(s, "tan") == 0)
                    push(tan(pop()));
                else if (strcmp(s, "exp") == 0)
                    push(exp(pop()));
                else if (strcmp(s, "log") == 0)
                    push(log(pop()));
                else if (strcmp(s, "pow") == 0) {
                    op2 = pop();
                    push(pow(pop(), op2));
                } else if (index(s[0]) != -1 && s[1] == '\0')
                    pusht(s[0]);
                else
                    printf("error: unknown function or variable %s\n", s);
                if (errno)
                    printf("error: problem in calculating %s\n", s);
                break;
            case '=':
                op2 = pop();
                if (setvar(popt(), op2))
                    push(op2);
                else
                    printf("error: only variables can be assigned\n");
                break;
            case '\n':
                op2 = pop();
                printf("\t%.8g\n", op2);
                setvar('Z', op2);    /* stores printed value */
                break;
            /* end of code to handle variables */

            /* default label omitted */
        }
    }

    return 0;
}

#define MAXVAL 100

int sp = 0;
double val[MAXVAL];
int valt[MAXVAL];    /* stack for types */
double var[26+1];    /* a-z and Z */

int index(int c)
{
    int i;
    char s[] = "abcdefghijklmnopqrstuvwxyzZ";

    assert(sizeof(s)-1 == sizeof(var)/sizeof(var[0]));

    for (i = 0; s[i] != '\0'; i++)
        if (s[i] == c)
            return i;

    return -1;
}

int setvar(int c, double v)
{
    int idx;

    if ((idx = index(c)) != -1) {
        var[idx] = v;
        return 1;
    } else
        return 0;
}

void push(double f)
{
    if (sp < MAXVAL) {
        val[sp] = f;
        valt[sp++] = NUMBER;
    } else
        printf("error: stack full, can't push %g\n", f);
}

double pop(void)
{
    if (sp > 0) {
        if (valt[--sp] == NUMBER)
            return val[sp];
        else {    /* variable referenced */
            int idx;
            idx = index(valt[sp]);
            assert(idx >= 0 && idx < sizeof(var)/sizeof(var[0]));
            return var[idx];    /* value in variable returned */
        }
    } else {
        printf("error: stack empty\n");
        return 0.0;
    }
}

void pusht(int t)
{
    assert(index(t) != -1);

    if (sp < MAXVAL) {
        val[sp] = 0.0;
        valt[sp++] = t;
    } else
        printf("error: stack full, can't push '%c'\n", t);
}

int popt(void)
{
    if (sp > 0)
        return valt[--sp];
    else
        printf("error: stack empty\n");
        return NUMBER;
}

void clear(void)
{
    sp = 0;
}

#include <ctype.h>

int getch(void);
void ungetch(int);

int getop(char s[])
{
    int i, c;

    while ((s[0] = c = getch()) == ' ' || c == '\t')
        ;
    s[1] = '\0';

    i = 0;
    if (isalpha(c)) {
        while (isalpha(s[++i] = c = getch()))
            ;
        s[i] = 0;
        if (c != EOF)
            ungetch(c);
        return NAME;    /* FUNCTION changed to NAME */
    }

    if (!isdigit(c) && c != '.' && c != '-')
        return c;

    if (c == '-') {
        c = getch();
        if (isdigit(c) || c == '.')
            s[++i] = c;
        else {
            if (c != EOF)
                ungetch(c);
            return '-';
        }
    }

    if (isdigit(c))
        while (isdigit(s[++i] = c = getch()))
            ;
    if (c == '.')
        while (isdigit(s[++i] = c = getch()))
            ;
    s[i] = '\0';
    if (c != EOF)
        ungetch(c);

    return NUMBER;
}

/* getch(), ungetch() and their relevant macros and variables omitted */


/* end of 4-06.c */
