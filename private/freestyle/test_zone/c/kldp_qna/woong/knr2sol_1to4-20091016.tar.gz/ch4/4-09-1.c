/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-07
 *
 * 4-9 (p.79): Our getch and ungetch do not handle a pushed-back EOF correctly.
 *             Decide what their properties ought to be if an EOF is pushed
 *             back, then implement your design.
 *
 * When making ungetch() handle EOF, the most important thing is to change the
 * type of buf. The char type is not supposed to represent all the possible
 * characters plus EOF; if char is signed, a valid character (e.g., 0xFF) whose
 * value is greater than SCHAR_MAX may happen to be equal to EOF (e.g., -1) when
 * stored in buf, and if unsigned, EOF may happen to be equal to a valid
 * character whose value is greater than SCHAR_MAX when stored in buf.
 *
 * There are various possible ways to handle EOF pushed back. ungetc() provided
 * by the standard library returns EOF (indicating a failure) remembering
 * nothing when EOF is given. This property is especially useful when passing a
 * burden of handling of EOF on an outer loop as you can see in 1-24-3.c. This
 * solution mimics ungets()'s behavior; it does nothing when EOF given.
 *
 * Note that, since EOF is never a valid pushed-back character, choosing EOF as
 * a signal for the pushback buffer is empty still makes sense.
 *
 * Using the return statement with no expression can be used in ungetch().
 */

#include <stdio.h>

#include <ctype.h>

int buf = EOF;

int getch(void)
{
    int c;

    if (buf != EOF) {
        c = buf;
        buf = EOF;
        return c;
    } else
        return getchar();
}

void ungetch(int c)
{
    if (c != EOF) {
        if (buf != EOF)
            printf("ungetch: too many characters\n");
        else
            buf = c;
    }
}

main()
{
    int c;

    while ((c = getch()) != EOF) {
        if (isdigit(c) && (c-'0') % 2 == 0) {
            ungetch(++c);
            ungetch(EOF);    /* no effect */
        } else
            putchar(c);
    }

    return 0;
}


/* end of 4-09-1.c */
