/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-15
 *
 * 4-14 (p.91): Define a macro swap(t,x,y) that interchanges two arguments of
 *              type t. (Block structure will help.)
 *
 * There is no way to implement a swap macro that is guaranteed to always work
 * (see below). Using an identifier with a leading underscore for a temporary
 * variable would help to avoid the temporary variable from having the same name
 * as one of arguments, but nobody can stop a user from calling it with a
 * variable having that name as in swap(char *, _t, _s).
 *
 * Another trick to avoid potential name conflict is to use the token-pasting
 * operator, ## as in:
 *
 *     #define swap(t, x, y) { t prefix ## x ## y;      \
 *                             prefix ## x ## y = x;    \
 *                             x = y;                   \
 *                             y = prefix ## x ## y; }
 *
 * where identifiers given for x and y are concatenated to construct a unique
 * name and a prefix is prepended to it in order to avoid conflicting with a
 * reserved identifier by the standard or an implementation. Note that, however,
 * even in this case, a user program can spoil the macro by providing an
 * argument with an identifier that repeats that prefix until it exceeds the
 * significant length of identifiers as in:
 *
 *     swap(int, prefixprefix, y);
 *
 * where the significant length is assumed to be 10 (I just picked this number
 * as an example). This call results in:
 *
 *     { int prefixprefixprefixy;
 *       prefixprefixprefixy = prefixprefix;
 *       prefixprefix = y;
 *       y = prefixprefixprefixy; }
 *
 * that is, considering the significant length of identifiers, equivalent to:
 *
 *     { int prefixpref;
 *       prefixpref = prefixpref;
 *       prefixpref = y;
 *       y = prefixpref; }
 *
 * Somebody might know that the bitwise XOR operator or an arithmetic operator
 * like subtraction can help to make a swap macro with no temporary variable.
 * Problems of such macros are well known and thus highly discouraged (see "C
 * Programming FAQs" by Steve Summit).
 *
 * I emphasize that, there is NO way to implement a swap macro that ALWAYS
 * works!
 *
 * When using a simple block structure for a macro, note what happens if the
 * macro is used as a branch of an if statement:
 *
 *     if (cond)
 *         swap(int, i1, i2);
 *     else
 *         swap(double, d1, d2);
 *
 * The extra semicolon following the first call to swap() that makes the call
 * look like a function call prevents connecting the else branch to the if
 * statement. There are two common ways to solve that problem.
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define swap(t,x,y) { t _t; _t = x; x = y; y = _t; }

main()
{
    int i;
    time_t t;
    int i1, i2;
    double d1, d2;
    void *p1, *p2;
    unsigned seed;

    t = time(NULL);
    assert(t != (time_t)-1);

    /* gets seed from time() */
    seed = 0;
    for (i = 0; i < sizeof(t); i++)
        seed += ((unsigned char *)&t)[i];
    srand(seed);

    i1 = ((double)rand() / RAND_MAX) * 100;    /* [0, 100] */
    i2 = ((double)rand() / RAND_MAX) * 100;    /* [0, 100] */

    d1 = (double)rand() / RAND_MAX;    /* [0, 1] */
    d2 = (double)rand() / RAND_MAX;    /* [0, 1] */

    p1 = &i1;
    p2 = &d2;

    printf("before: %d, %d\n", i1, i2);
    swap(int, i1, i2);
    printf("after: %d, %d\n", i1, i2);

    printf("before: %f, %f\n", d1, d2);
    swap(double, d1, d2);
    printf("after: %f, %f\n", d1, d2);

    printf("before: %p, %p\n", p1, p2);
    swap(void *, p1, p2);
    printf("after: %p, %p\n", p1, p2);

    return 0;
}


/* end of 4-14-1.c */
