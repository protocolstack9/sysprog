/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-06
 *
 * 4-8 (p.79): Suppose there will never be more than one character of pushback.
 *             Modify getch and ungetch accordingly.
 */

#include <stdio.h>

#include <ctype.h>

int buf = EOF;

int getch(void)
{
    int c;

    if (buf != EOF) {
        c = buf;
        buf = EOF;
        return c;
    } else
        return getchar();
}

void ungetch(int c)
{
    if (buf != EOF)
        printf("ungetch: too many characters\n");
    else
        buf = c;
}

main()
{
    int c;

    while ((c = getch()) != EOF) {
        if (isdigit(c) && (c-'0') % 2 == 0)
            ungetch(++c);
        else
            putchar(c);
    }

    return 0;
}


/* end of 4-08-1.c */
