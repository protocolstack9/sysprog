/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-28
 *
 * 4-5 (p.79): Add access to library functions like sin, exp, and pow. See
 *             <math.h> in Appendix B, Section 4.
 *
 * The solution given here is intended to minimally modify the existing
 * calculator code in the answer to 4-4. To run this, you should copy the
 * omitted parts from the text and the answer.
 *
 * The math functions, sin, cos, tan, exp, log and pow are supported. Error
 * conditions occurred in calculating those functions are handled by inspecting
 * errno declared in <errno.h>
 */

#include <errno.h>     /* added for errno */
#include <string.h>    /* added for strcmp() */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#define MAXOP 100
#define NUMBER '0'
#define FUNCTION '1'    /* signal that a function was found */

int getop(char []);
void push(double);
double pop(void);
void clear(void);

main()
{
    int type;
    double op2;
    char s[MAXOP];

    while ((type = getop(s)) != EOF) {
        switch(type) {
            /* case labels from NUMBER to '!' omitted */

            /* start of code to handle math functions */
            case FUNCTION:
                errno = 0;
                if (strcmp(s, "sin") == 0)
                    push(sin(pop()));
                else if (strcmp(s, "cos") == 0)
                    push(cos(pop()));
                else if (strcmp(s, "tan") == 0)
                    push(tan(pop()));
                else if (strcmp(s, "exp") == 0)
                    push(exp(pop()));
                else if (strcmp(s, "log") == 0)
                    push(log(pop()));
                else if (strcmp(s, "pow") == 0) {
                    op2 = pop();
                    push(pow(pop(), op2));
                } else
                    printf("error: unknown function %s\n", s);
                if (errno)
                    printf("error: problem in calculating %s\n", s);
                break;
            /* end of code to handle math functions */

            /* case label for '\n' and default label omitted */
        }
    }

    return 0;
}

/* push(), pop(), clear() and their relevant macros and variables omitted */

#include <ctype.h>

int getch(void);
void ungetch(int);

int getop(char s[])
{
    int i, c;

    while ((s[0] = c = getch()) == ' ' || c == '\t')
        ;
    s[1] = '\0';

    /* start of code to support math functions */
    i = 0;    /* initialization moved up here */
    if (isalpha(c)) {
        while (isalpha(s[++i] = c = getch()))
            ;
        s[i] = 0;
        if (c != EOF)
            ungetch(c);
        return FUNCTION;
    }
    /* end of code to support math functions */

    if (!isdigit(c) && c != '.' && c != '-')
        return c;

    if (c == '-') {
        c = getch();
        if (isdigit(c) || c == '.')
            s[++i] = c;
        else {
            if (c != EOF)
                ungetch(c);
            return '-';
        }
    }

    if (isdigit(c))
        while (isdigit(s[++i] = c = getch()))
            ;
    if (c == '.')
        while (isdigit(s[++i] = c = getch()))
            ;
    s[i] = '\0';
    if (c != EOF)
        ungetch(c);

    return NUMBER;
}

/* getch(), ungetch() and their relevant macros and variables omitted */


/* end of 4-05.c */
