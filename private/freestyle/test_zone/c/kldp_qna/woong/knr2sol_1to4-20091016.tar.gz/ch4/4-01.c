/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 4-1 (p.71): Write the function strindex(s,t) which returns the position of
 *             the rightmost occurrence of t in s, or -1 if there is none.
 *
 * One ambiguous case is when t is an empty string, that is, calling
 * strrindex() with "" given for t. Since strindex() in K&R2 is designed to
 * always fail finding an empty string, strrindex() is also done in that way. It
 * is not difficult, however, to change the behavior; replacing "k > 0" with
 * "k >= 0" makes strrindex() always success in finding an emptry string with
 * returning the position of the terminating null character.
 */

#include <string.h>

#include <stdio.h>

int strrindex(char s[], char t[])
{
    int n, m;
    int i, j, k;

    n = strlen(s);
    m = strlen(t);

    for (i = n-m; i >= 0; i--) {
        for (j=i, k=0; t[k] != '\0' && s[j] == t[k]; j++, k++)
            ;
        if (k > 0 && t[k] == '\0')
            return i;
    }

    return -1;
}

main()
{
    char *test[][2] = {
        "", "",
        "", "test",
        "test str for test", "",
        "test str for test", "test",
        "test str for test", " ",
        "test str for test", "string",
        "test str for test", "longer str for test"
    };
    int i, idx, len;

    for (i = 0; i < sizeof(test)/sizeof(test[0]); i++) {
        len = strlen(test[i][1]);
        idx = strindex(test[i][0], test[i][1]);
        printf("finding last occurrence of \"%s\" in \"%s\" - ",
               test[i][1], test[i][0]);
        if (idx < 0)
            printf("not found\n");
        else
            printf("\"%.*s\" found at %d\n", len, test[i][0]+idx, idx);
    }

    return 0;
}


/* end of 4-01.c */
