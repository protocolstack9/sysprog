/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-13
 *
 * 4-10 (p.79): An alternate organization uses getline to read an entire input
 *              line; this makes getch and ungetch unnecessary. Revise the
 *              calculator to use this approach.
 *
 * The solution given here is intended to minimally modify the existing
 * calculator code in the answer to 4-6. To run this, you should copy the
 * omitted parts from the text and the answer.
 *
 * When scanning a string to obtain input characters, calling getch() is mapped
 * to increasing the index for the string. Even if it is intended that the
 * revised code keeps its original structure as much as possible, there are a
 * few things to note:
 * - adjusting an index to the line buffer properly;
 * - signaling EOF by hand when there is no more input lines (a string does not
 *   ends with EOF but a null character); and
 * - getline() revised to correctly handle a line ending with no newline (with
 *   no aid from getline(), getop() should get even more complicated to handle
 *   such a line by itself or its handling should be adandoned).
 *
 * In the code, buf[bufp] is the next character to read. buf[bufp++] is mapped
 * to getch() and bufp-- to ungetch(). Comments in getop() help understanding
 * the logic.
 *
 * By adjusting the timings when bufp increased, the variable c and decreasing
 * bufp can be avoided.
 */

#include <assert.h>
#include <errno.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

/* main() and its relevant macros omitted */

/* index(), setvar(), push(), pop(), pusht(), popt(), clear() and their relevant
   macros and variables omitted */

#include <ctype.h>

#define MAX_LINE 80

/* declarations for getch() and ungetch() removed */
int getline(char [], int);    /* added */

/* buffer and index for reading lines */
char buf[MAX_LINE];
int bufp;

int getop(char s[])
{
    int i, c;

    if (buf[bufp] == '\0') {
        if (getline(buf, sizeof(buf)) == 0)
            return EOF;
        bufp = 0;
    }

    while ((s[0] = c = buf[bufp++]) == ' ' || c == '\t')
        ;
    /* c is first non-space char and buf[bufp] is next to that */
    s[1] = '\0';

    i = 0;
    if (isalpha(c)) {
        while (isalpha(s[++i] = c = buf[bufp++]))
            ;
        /* c is next to last alphabet char and buf[bufp] is next to that */
        s[i] = 0;
        bufp--;
        /* buf[bufp] is next to last alphabet char */
        return NAME;
    }

    if (!isdigit(c) && c != '.' && c != '-')
        return c;

    if (c == '-') {
        c = buf[bufp++];
        if (isdigit(c) || c == '.')
            s[++i] = c;
        else {
            /* c is next to '-' and buf[bufp] is next to that */
            bufp--;
            /* buf[bufp] is next to '-' */
            return '-';
        }
    }

    if (isdigit(c))
        while (isdigit(s[++i] = c = buf[bufp++]))
            ;
    /* c is next to last char of number and buf[bufp] is next to that */
    if (c == '.')
        while (isdigit(s[++i] = c = buf[bufp++]))
            ;
    /* c is next to last char of number and buf[bufp] is next to that */
    s[i] = '\0';
    bufp--;
    /* buf[bufp] is next to last char of number */

    return NUMBER;
}

#include <stdio.h>

/* getline() from 1-16.c */
int getline(char s[], int lim)
{
    int c, i;

    for (i = 0; i < lim-1 && ((c = getchar()) != EOF && c != '\n'); ++i)
        s[i] = c;

    if (c == '\n') {
        s[i] = c;
        ++i;
    } else if (c == EOF) {    /* for the last line with no newline */
        if (i > 0) {
            s[i] = '\n';
            ++i;
        }
    } else {
        /* if the buffer is full and the next call to getchar() gives EOF, the
           next call to getline() will return 0 rather than correctly compensate
           the missing newline; this modification is for such a case */
        c = getchar();
        ungetc((c == EOF)? '\n': c, stdin);
    }
    s[i] = '\0';

    return i;
}

/* getch() and ungetch() are no longer necessary */


/* end of 4-10-1.c */
