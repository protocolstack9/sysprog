/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-06
 *
 * 4-9 (p.79): Our getch and ungetch do not handle a pushed-back EOF correctly.
 *             Decide what their properties ought to be if an EOF is pushed
 *             back, then implement your design.
 *
 * The explanatory answer is given in 4-09-1.c.
 */

#include <stdio.h>

#include <ctype.h>

int buf = EOF;

int getch(void)
{
    int c;

    if (buf != EOF) {
        c = buf;
        buf = EOF;
        return c;
    } else
        return getchar();
}

void ungetch(int c)
{
    if (c == EOF)
        return;
    else if (buf != EOF)
        printf("ungetch: too many characters\n");
    else
        buf = c;
}

main()
{
    int c;

    while ((c = getch()) != EOF) {
        if (isdigit(c) && (c-'0') % 2 == 0) {
            ungetch(++c);
            ungetch(EOF);    /* no effect */
        } else
            putchar(c);
    }

    return 0;
}


/* end of 4-09-2.c */
