/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-14
 *
 * 4-13 (p.88): Write a recursive version of the function reverse(s), which
 *              reverses the string s in place.
 *
 * Using the pointer arithmetic instead of an integral index simplifies the
 * code.
 */

#include <string.h>

#include <stdio.h>

void do_reverse(char s[], int m, int n)
{
    int c;

    if (n > m) {
        c = s[m];
        s[m] = s[n];
        s[n] = c;
        do_reverse(s, m+1, n-1);
    }
}

void reverse(char s[])
{
    do_reverse(s, 0, strlen(s)-1);
}

#define MAX_LINE 80    /* maximum input line length */

/* getline() from 1-19.c */
int getline(char s[], int lim)
{
    int c, i;

    for (i = 0; i < lim-1 && ((c = getchar()) != EOF && c != '\n'); ++i)
        s[i] = c;

    if (c == '\n') {
        s[i] = c;
        ++i;
    } else if (c == EOF) {    /* for the last line with no newline */
        if (i > 0) {
            s[i] = '\n';
            ++i;
        }
    } else {
        /* if the buffer is full and the next call to getchar() gives EOF, the
           next call to getline() will return 0 rather than correctly compensate
           the missing newline; this modification is for such a case */
        c = getchar();
        ungetc((c == EOF)? '\n': c, stdin);
    }
    s[i] = '\0';

    return i;
}

main()
{
    int n;
    char line[MAX_LINE];

    while ((n = getline(line, MAX_LINE)) > 0) {
        if (line[n-1] == '\n')
            line[n-1] = '\0';
        reverse(line);
        printf("%s\n", line);
    }

    return 0;
}


/* end of 4-13-1.c */
