/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-13
 *
 * 4-10 (p.79): An alternate organization uses getline to read an entire input
 *              line; this makes getch and ungetch unnecessary. Revise the
 *              calculator to use this approach.
 *
 * The solution given here is intended to minimally modify the existing
 * calculator code in the answer to 4-6. To run this, you should copy the
 * omitted parts from the text and the answer.
 *
 * When scanning a string to obtain input characters, calling getch() is mapped
 * to increasing the index for the string. Even if it is intended that the
 * revised code keeps its original structure as much as possible, there are a
 * few things to note:
 * - adjusting an index to the line buffer properly;
 * - signaling EOF by hand when there is no more input lines (a string does not
 *   ends with EOF but a null character); and
 * - getline() revised to correctly handle a line ending with no newline (with
 *   no aid from getline(), getop() should get even more complicated to handle
 *   such a line by itself or its handling should be adandoned).
 *
 * Comparing to 4-10-1.c, the timings when bufp increased are adjusted to avoid
 * using the variable c and decreasing bufp; as the result, buf[bufp] serves for
 * c in all places. Comments in getop() help understanding the changes.
 */

#include <assert.h>
#include <errno.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

/* main() and its relevant macros omitted */

/* index(), setvar(), push(), pop(), pusht(), popt(), clear() and their relevant
   macros and variables omitted */

#include <ctype.h>

#define MAX_LINE 80

/* declarations for getch() and ungetch() removed */
int getline(char [], int);    /* added */

/* buffer and index for reading lines */
char buf[MAX_LINE];
int bufp;

int getop(char s[])
{
    int i;

    if (buf[bufp] == '\0') {
        if (getline(buf, sizeof(buf)) == 0)
            return EOF;
        bufp = 0;
    }

    while ((s[0] = buf[bufp]) == ' ' || buf[bufp] == '\t')
        bufp++;
    /* buf[bufp] is first non-space char */
    s[1] = '\0';

    i = 0;
    if (isalpha(buf[bufp])) {
        /* buf[bufp] stored, thus ++bufp */
        while (isalpha(s[++i] = buf[++bufp]))
            ;
        /* buf[bufp] is next to last alphabet char */
        s[i] = 0;
        return NAME;
    }

    if (!isdigit(buf[bufp]) && buf[bufp] != '.' && buf[bufp] != '-')
        return buf[bufp++];    /* consume buf[bufp] and bufp++ */

    if (buf[bufp] == '-') {
        /* buf[bufp] (that is '-') stored, thus ++bufp */
        if (isdigit(buf[++bufp]) || buf[bufp] == '.')
            s[++i] = buf[bufp];
        else
            /* buf[bufp] is next to '-' */
            return '-';
    }

    if (isdigit(buf[bufp]))
        /* buf[bufp] stored, thus ++bufp */
        while (isdigit(s[++i] = buf[++bufp]))
            ;
    /* buf[bufp] is next to last char of number */
    if (buf[bufp] == '.')
        /* buf[bufp] stored, thus ++bufp */
        while (isdigit(s[++i] = buf[++bufp]))
            ;
    s[i] = '\0';
    /* buf[bufp] is next to last char of number */

    return NUMBER;
}

#include <stdio.h>

/* getline() from 1-16.c */
int getline(char s[], int lim)
{
    int c, i;

    for (i = 0; i < lim-1 && ((c = getchar()) != EOF && c != '\n'); ++i)
        s[i] = c;

    if (c == '\n') {
        s[i] = c;
        ++i;
    } else if (c == EOF) {    /* for the last line with no newline */
        if (i > 0) {
            s[i] = '\n';
            ++i;
        }
    } else {
        /* if the buffer is full and the next call to getchar() gives EOF, the
           next call to getline() will return 0 rather than correctly compensate
           the missing newline; this modification is for such a case */
        c = getchar();
        ungetc((c == EOF)? '\n': c, stdin);
    }
    s[i] = '\0';

    return i;
}

/* getch() and ungetch() are no longer necessary */


/* end of 4-10-2.c */
