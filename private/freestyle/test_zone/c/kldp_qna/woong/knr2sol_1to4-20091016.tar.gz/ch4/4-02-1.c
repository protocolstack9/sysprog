/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 4-2 (p.73): Extend atof to handle scientific notation of the form
 *                 123.45e-6
 *             where a floating-point number may be followed by e or E and an
 *             optionally signed exponent.
 *
 * When an exponent after 'e' or 'E' is negative, this solution repeatedly
 * multiplies 0.1 to a calculated value to get the final answer rather than
 * divides it by 10. Since 0.1 cannot be represented exactly on binary
 * floating-point implementations, multiplying it several times results in a
 * loss of significance.
 *
 * Besides, applying an exponent before making a fractional part may result in
 * a premature overflow; for example when the largest representable value is
 * greater than 10 powered to 37, 0.99999e37 causes an overflow since the
 * calculation performed is 99999 * pow(10, 37) / 100000.
 *
 * Also note that myatof() returns 0.0 if only an exponent part is given as in
 * "e-10".
 *
 * Converting the decimal string representation of a floating-point number to a
 * (non-decimal) internal floating-point representation is not an easy problem;
 * see "How to Read
 * Floating-Point Numbers Accurately" by William D. Clinger and "Correctly
 * Rounded Binary-Decimal and Decimal-Binary Conversions" by David M. Gay. The
 * code given in K&R2 and here is never for use in product code.
 *
 * For test this solution #includes <stdlib.h> which defines atof(). Thus, the
 * function name is changed to myatof().
 */

#include <ctype.h>

#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* first half comes from K&R2 */
double myatof(char s[])
{
    double val, power;
    int i, sign;

    for (i = 0; isspace(s[i]); i++)
        ;
    sign = (s[i] == '-') ? -1 : 1;
    if (s[i] == '+' || s[i] == '-')
        i++;
    for (val = 0.0; isdigit(s[i]); i++)
        val = 10.0 * val + (s[i] - '0');
    if (s[i] == '.')
        i++;
    for (power = 1.0; isdigit(s[i]); i++) {
        val = 10.0 * val + (s[i] - '0');
        power *= 10;
    }

    if (s[i] == 'e' || s[i] == 'E') {
        int e;
        double n;

        n = (s[++i] == '-')? 0.1: 10.0;
        if (s[i] == '+' || s[i] == '-')
            i++;
        for (e = 0; isdigit(s[i]); i++)
            e = 10 * e + (s[i] - '0');
        while (e-- > 0)
            val *= n;
    }

    return sign * val / power;
}

main()
{
    int i, e;
    double n;
    time_t t;
    unsigned seed;
    const char *sign[] = { "", "+", "-" };
    char buf[sizeof("0.12345e+37")], buf2[sizeof(buf)], *endp;

    t = time(NULL);
    assert(t != (time_t)-1);

    /* gets seed from time() */
    seed = 0;
    for (i = 0; i < sizeof(t); i++)
        seed += ((unsigned char *)&t)[i];
    srand(seed);

    for (i = 0; i < 10; i++) {
        n = (double)rand() / RAND_MAX;           /* [0, 1] */
        e = ((double)rand() / RAND_MAX) * 37;    /* [0, 37] */
        sprintf(buf, "%.5f%c%s%d", n, ((e % 2)? 'e': 'E'), sign[e % 3], e);
        errno = 0;
        n = strtod(buf, &endp);
        assert(errno == 0 && *endp == '\0');

        sprintf(buf2, "%.5e", myatof(buf));
        sprintf(buf, "%.5e", n);

        printf("myatof() gives %s for %s", buf2, buf);
        if (strcmp(buf, buf2) == 0)
            putchar('\n');
        else
            printf(" - different (but may not be wrong)\n");
    }

    return 0;
}


/* end of 4-02-1.c */
