/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-15
 *
 * 4-12 (p.88): Adapt the ideas of printd to write a recursive version of itoa;
 *              that is, convert an integer into a string by calling a recursive
 *              routine.
 *
 * As in 3-04-2.c, this answer assumes that integral division always truncates
 * even for negative operands, which is guaranteed by C99.
 *
 * The interface to itoa() changes back to the original form since there is
 * nothing to return now. Note when the static pointer p is set; it is set to s
 * when starting to return back from recursive calls and adjusted properly by
 * subsequent operations as the depth of recursion gets smaller.
 */

#include <stdio.h>
#include <limits.h>
#include <string.h>

void itoa(int n, char s[])
{
    static char *p;

    if (n / 10 != 0) {
        itoa(n / 10, s);
    } else {
        p = s;
        if (n < 0)
            *p++ = '-';
        *p = '\0';
    }

    *p++ = '0' - (n % 10);
    *p = '\0';
}

main()
{
    int i;
    char buf1[CHAR_BIT*sizeof(int)/3+1+1];
    char buf2[CHAR_BIT*sizeof(int)/3+1+1];

    /* see 3-04-1.c for the infinite loop below */
    i = INT_MIN;
    while (1) {
        sprintf(buf1, "%d", i);
        itoa(i, buf2);    /* UB when i == INT_MIN */
        if (strcmp(buf1, buf2) != 0)
            printf("failed - sprintf() gives %s and itoa() gives %s for %d\n",
                   buf1, buf2, i);
        if (i % (INT_MAX / 500) == 0) {
            if (i < 0)
                printf("%.1f%% done\n", (double)(INT_MIN-i) * 50 / -INT_MAX);
            else
                printf("%.1f%% done\n", (double)i * 50 / INT_MAX + 50);
        }
        if (i == INT_MAX)
            break;
        i++;
    }

    return 0;
}


/* end of 4-12-6.c */
