/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 4-2 (p.73): Extend atof to handle scientific notation of the form
 *                 123.45e-6
 *             where a floating-point number may be followed by e or E and an
 *             optionally signed exponent.
 *
 * This solution differs from the former solution in that:
 * - the fractional part of a number is scaled by 0.1 rather than scaled by 10
 *   with a scale factor, thus for example an innocent number with many trailing
 *   zeros does not result in intermediate overflow;
 * - integral overflow check when accumulating an exponent is added;
 * - over/underflow checks for applying an exponent are added (considering
 *   round-off errors of floating-point arithmetic, >= and <= are used instead
 *   of > and < that are more mathematically accurate);
 * - the sign of a number is applied after applying an exponent to keep the
 *   over/underflow check in a simpler form.
 *
 * See the references mentioned in the former solution for how difficult
 * the base conversion is.
 *
 * For test this solution #includes <stdlib.h> which defines atof(). Thus, the
 * function name is changed to myatof().
 */

#include <ctype.h>

#include <assert.h>
#include <errno.h>
#include <float.h>
#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

double myatof(char s[])
{
    double val, power;
    int sign;

    while (isspace(*s))
        s++;
    sign = (*s == '-')? -1: 1;
    if (*s == '+' || *s == '-')
        s++;
    for (val = 0.0; isdigit(*s); s++)
        val = 10.0 * val + (*s - '0');
    if (*s == '.')
        s++;
    for (power = 0.1; isdigit(*s); s++) {
        val = val + (power * (*s - '0'));
        power /= 10;
    }

    if (*s == 'e' || *s == 'E') {
        int esign, e;

        esign = (*++s == '-')? -1: 1;
        if (*s == '+' || *s == '-')
            s++;
        for (e = 0; isdigit(*s) && e <= (INT_MAX-(*s-'0'))/10; s++)
            e = 10 * e + (*s - '0');
        while (e-- > 0)
            if (esign > 0) {
                if (val >= DBL_MAX / 10) {    /* check for overflow */
                    val = HUGE_VAL;
                    break;
                }
                val *= 10;
            } else {
                if (val <= DBL_MIN * 10) {    /* check for underflow */
                    val = 0.0;
                    break;
                }
                val /= 10;
            }
    }

    return sign * val;
}

main()
{
    int i, e;
    double n;
    time_t t;
    unsigned seed;
    const char *sign[] = { "", "+", "-" };
    char buf[sizeof("0.12345e+37")], buf2[sizeof(buf)], *endp;

    t = time(NULL);
    assert(t != (time_t)-1);

    /* gets seed from time() */
    seed = 0;
    for (i = 0; i < sizeof(t); i++)
        seed += ((unsigned char *)&t)[i];
    srand(seed);

    for (i = 0; i < 10; i++) {
        n = (double)rand() / RAND_MAX;           /* [0, 1] */
        e = ((double)rand() / RAND_MAX) * 37;    /* [0, 37] */
        sprintf(buf, "%.5f%c%s%d", n, ((e % 2)? 'e': 'E'), sign[e % 3], e);
        errno = 0;
        n = strtod(buf, &endp);
        assert(errno == 0 && *endp == '\0');

        sprintf(buf2, "%.5e", myatof(buf));
        sprintf(buf, "%.5e", n);

        printf("myatof() gives %s for %s", buf2, buf);
        if (strcmp(buf, buf2) == 0)
            putchar('\n');
        else
            printf(" - different (but may not be wrong)\n");
    }

    return 0;
}


/* end of 4-02-3.c */
