/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 4-4 (p.79): Add commands to print the top element of the stack without
 *             popping, to duplicate it, and to swap the top two elements. Add
 *             a command to clear the stack.
 *
 * The solution given here is intended to minimally modify the existing
 * calculator code in the answer to 4-3. To run this, you should copy the
 * omitted parts from the text and the answer.
 *
 * Four characters, #, &, ^ and ! are selected for printing the top element,
 * duplicating it, swapping the top two elements and clearing the stack,
 * respectively.
 */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#define MAXOP 100
#define NUMBER '0'

int getop(char []);
void push(double);
double pop(void);
void clear(void);    /* implements ! */

main()
{
    int type;
    double op2;
    char s[MAXOP];

    while ((type = getop(s)) != EOF) {
        switch(type) {
            /* case labels from NUMBER to '%' omitted */

            /* start of code to handle 4 new commands */
            case '#':    /* prints top element */
                op2 = pop();
                printf("top element: %.8g\n", op2);
                push(op2);
                break;
            case '&':    /* duplicates top element */
                op2 = pop();
                push(op2);
                push(op2);
                break;
            case '^':    /* swaps top two elements */
                {
                    double op;
                    op = pop();
                    op2 = pop();
                    push(op);
                    push(op2);
                }
                break;
            case '!':    /* clears the stack */
                clear();
                break;
            /* end of code to handle 4 new commands */

            /* case label for '\n' and default label omitted */
        }
    }

    return 0;
}

#define MAXVAL 100

int sp = 0;
double val[MAXVAL];

/* push and pop() omitted */

void clear(void)
{
    sp = 0;
}

/* getop() and ungetch() omitted */

/* getch(), ungetch() and their relevant macros and variables omitted */


/* end of 4-04.c */
