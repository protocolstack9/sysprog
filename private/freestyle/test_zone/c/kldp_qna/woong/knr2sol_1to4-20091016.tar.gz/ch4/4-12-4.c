/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-14
 *
 * 4-12 (p.88): Adapt the ideas of printd to write a recursive version of itoa;
 *              that is, convert an integer into a string by calling a recursive
 *              routine.
 *
 * This solution converts itoa() given in 3-04-2.c. See the explanation in
 * 3-04-2.c for the algorithm used.
 */

#include <stdio.h>
#include <limits.h>
#include <string.h>

char *do_itoa(int n, char *s)
{
    if (n / 10 != 0)
        s = do_itoa(n / 10, s);
    *s = '0' - (n % 10);

    return s+1;
}

void itoa(int n, char s[])
{
    if (n < 0)
        *s++ = '-';
    else
        n = -n;

    s = do_itoa(n, s);
    *s = '\0';
}

main()
{
    int i;
    char buf1[CHAR_BIT*sizeof(int)/3+1+1];
    char buf2[CHAR_BIT*sizeof(int)/3+1+1];

    /* see 3-04-1.c for the infinite loop below */
    i = INT_MIN;
    while (1) {
        sprintf(buf1, "%d", i);
        itoa(i, buf2);    /* UB when i == INT_MIN */
        if (strcmp(buf1, buf2) != 0)
            printf("failed - sprintf() gives %s and itoa() gives %s for %d\n",
                   buf1, buf2, i);
        if (i % (INT_MAX / 500) == 0) {
            if (i < 0)
                printf("%.1f%% done\n", (double)(INT_MIN-i) * 50 / -INT_MAX);
            else
                printf("%.1f%% done\n", (double)i * 50 / INT_MAX + 50);
        }
        if (i == INT_MAX)
            break;
        i++;
    }

    return 0;
}


/* end of 4-12-4.c */
