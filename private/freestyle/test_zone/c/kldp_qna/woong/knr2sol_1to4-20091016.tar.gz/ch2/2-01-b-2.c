/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 2-1B (p.36): Write a program to determine the ranges of char, short, int and
 *              long variables, both signed and unsigned, by printing
 *              appropriate values from standard headers and by direct
 *              computation. Harder if you compute them: (2-1A) determine the
 *              ranges of the various floating-point types.
 *
 * The algorithms used in this answer is too complicated to explain briefly; see
 * enquire.c by Steven Pemberton and "MACHAR: A Subroutine to Dynamically
 * Determine Machine Parameters" by W. J. Cody.
 *
 * For duplication of code, this answer takes heavy advantage of macros. Very
 * long replacement lists may crash a conforming preprocessor. enquire.c also
 * provides a smart (or tricky?) way to get around this problem.
 *
 * Be warned that applying high-level optimizations (e.g., inlining functions)
 * may keep the code from working correctly.
 */

#include <stdio.h>
#include <setjmp.h>
#include <signal.h>
#include <stdlib.h>

#define ABS(x) (((x) > 0)? (x): -(x))

#define defstore(type, prefix)               \
    void prefix ## STORE(type *a, type b)    \
    {                                        \
        *a = b;                              \
    }

#define defop(type, prefix, name, op)      \
    type prefix ## name(type a, type b)    \
    {                                      \
        type c;                            \
        prefix ## STORE(&c, a op b);       \
        return c;                          \
    }

#define prepare_const(type, prefix)                   \
    type zero = (type) 0;                             \
    type one = (type) 1;                              \
    type two;                                         \
    prefix ## STORE(&two, prefix ## SUM(one, one))    \

#define getmin(result, type, p)                                               \
    do {                                                                      \
        type etop, ebot, epsp1, eps;                                          \
        type fmin, a, y, y1, z, z1, z2;                                       \
        type basein = p ## DIV(1, base);                                      \
                                                                              \
        prepare_const(type, p);                                               \
                                                                              \
        etop = one;                                                           \
        ebot = zero;                                                          \
        eps = p ## SUM(ebot, p ## DIV(p ## SUB(etop, ebot), two));            \
        while (eps != ebot && eps != etop) {                                  \
            epsp1 = p ## SUM(one, eps);                                       \
            if (epsp1 > one)                                                  \
                etop = eps;                                                   \
            else                                                              \
                ebot = eps;                                                   \
            eps = p ## SUM(ebot, p ## DIV(p ## SUB(etop, ebot), two));        \
        }                                                                     \
        if (p ## SUM(one, etop) <= one || p ## SUM(one, ebot) != one) {       \
            printf("something wrong in calculating eps!\n");                  \
            abort();                                                          \
        }                                                                     \
        eps = etop;                                                           \
                                                                              \
        y = zero;                                                             \
        z = basein;                                                           \
        z1 = p ## DIV (p ## SUM(1.0, eps), base);                             \
        if (setjmp(buf) == 0) {                                               \
            do {                                                              \
                y = z;                                                        \
                y1 = z1;                                                      \
                z = p ## MUL(y, y);                                           \
                z1 = p ## MUL(z1, y);                                         \
                a = p ## MUL(z, one);                                         \
                z2 = p ## DIV(z1, y);                                         \
            } while(z2 == y1 && p ## SUM(a, a) != zero && ABS(z) < y);        \
        }                                                                     \
        if (setjmp(buf) == 0) {                                               \
            do {                                                              \
                fmin = y;                                                     \
                z1 = y1;                                                      \
                y = p ## DIV(y, base);                                        \
                y1 = p ## DIV(y1, base);                                      \
                a = p ## MUL(y, one);                                         \
                z2 = p ## MUL(y1, base);                                      \
            } while (z2 == z1 && p ## SUM(a, a) != zero && ABS(y) < fmin);    \
        }                                                                     \
        *(result) = fmin;                                                     \
    } while(0)

#define getmax(result, type, p)                                           \
    do {                                                                  \
        type etop, ebot, eps, epsp1;                                      \
        int i, maxexp;                                                    \
        type fmax, newfmax;                                               \
                                                                          \
        prepare_const(type, p);                                           \
                                                                          \
        etop = one;                                                       \
        ebot = zero;                                                      \
        eps = p ## SUM(ebot, p ## DIV(p ## SUB(etop, ebot), two));        \
                                                                          \
        while (eps != ebot && eps != etop) {                              \
            epsp1 = p ## SUB(one, eps);                                   \
            if (epsp1 < one)                                              \
                etop = eps;                                               \
            else                                                          \
                ebot = eps;                                               \
            eps = p ## SUM(ebot, p ## DIV(p ## SUB(etop, ebot), two));    \
        }                                                                 \
        eps = etop;                                                       \
        if (p ## SUB(one, etop) >= one || p ## SUB(one, ebot) != one) {   \
            printf("something wrong in calculating epsneg!\n");           \
            abort();                                                      \
        }                                                                 \
                                                                          \
        maxexp = two;                                                     \
        fmax = one;                                                       \
        newfmax = base + one;                                             \
        while (fmax < newfmax) {                                          \
            fmax = newfmax;                                               \
            if (setjmp(buf) == 0)                                         \
                newfmax = p ## MUL(newfmax, base);                        \
            else                                                          \
                break;                                                    \
            if (p ## DIV(newfmax, base) != fmax && newfmax > fmax)        \
                break;                                                    \
            maxexp++;                                                     \
        }                                                                 \
        fmax = p ## SUB(one, eps);                                        \
        if (p ## MUL(fmax, one) != fmax)                                  \
            fmax = p ## SUB(one, p ## MUL(base, eps));                    \
        for (i = 1; i <= maxexp; i++)                                     \
            fmax = p ## MUL(fmax, base);                                  \
                                                                          \
        *(result) = fmax;                                                 \
    } while(0)

jmp_buf buf;

void trap(int ignored)
{
    signal(SIGFPE, trap);
    longjmp(buf, 1);
}

defstore(float, F)          /* no semicolon following */
defstore(double, D)         /* no semicolon following */
defstore(long double, L)    /* no semicolon following */

defop(float, F, SUM, +)    /* no semicolon following */
defop(float, F, SUB, -)    /* no semicolon following */
defop(float, F, MUL, *)    /* no semicolon following */
defop(float, F, DIV, /)    /* no semicolon following */

defop(double, D, SUM, +)    /* no semicolon following */
defop(double, D, SUB, -)    /* no semicolon following */
defop(double, D, MUL, *)    /* no semicolon following */
defop(double, D, DIV, /)    /* no semicolon following */

defop(long double, L, SUM, +)    /* no semicolon following */
defop(long double, L, SUB, -)    /* no semicolon following */
defop(long double, L, MUL, *)    /* no semicolon following */
defop(long double, L, DIV, /)    /* no semicolon following */

main()
{
    int base;

    if (setjmp(buf) == 0) {
        signal(SIGFPE, trap);

        {    /* FLT_RADIX */
            float a, b;
            prepare_const(float, F);
            a = one;
            if (setjmp(buf) == 0) {
                do {
                    a = FSUM(a, a);
                } while (FSUB(FSUB(FSUM(a, one), a), one) == zero);
            } else {
                printf("inexact exception shall not be enabled!\n");
                abort();    /* intentinally returns nothing */
            }

            b = one;
            do {
                b = FSUM(b, b);
            } while ((base = FSUB(FSUM(a, b), a)) == zero);

            printf("FLT_RADIX: %d\n", base);
        }

        {    /* FLT_MIN, FLT_MAX */
            float min, max;
            getmin(&min, float, F);
            getmax(&max, float, F);
            printf("FLT_MIN: %e, FLT_MAX: %e\n", min, max);
        }

        {    /* DBL_MIN, DBL_MAX */
            double min, max;
            getmin(&min, double, D);
            getmax(&max, double, D);
            printf("DBL_MIN: %e, DBL_MAX: %e\n", min, max);
        }

        {    /* LDBL_MIN, LDBL_MAX */
            long double min, max;
            getmin(&min, long double, L);
            getmax(&max, long double, L);
            printf("LDBL_MIN: %Le, LDBL_MAX: %Le\n", min, max);
        }
    } else
        printf("unexpected trap!\n");

    return 0;
}


/* end of 2-01-b-2.c */
