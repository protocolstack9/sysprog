/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 2-5 (p.48): Write the function any(s1,s2), which returns the first location
 *             in the string s1 where any character from the string s2 occurs,
 *             or -1 if s1 contains no characters from s2. (The standard library
 *             function strpbrk does the same job but returns a pointer to the
 *             location.)
 *
 * As shown in answering to 2-4, a table-based approach can improve the answer
 * in this case too.
 */

#include <stdio.h>
#include <string.h>

int any(char s1[], char s2[])
{
    char *p, *q;

    for (p = s1; *p; p++) {
        for (q = s2; *q; q++)
            if (*p == *q)
                return (p - s1);
    }

    return -1;
}

main()
{
    char *left[] = {
        "",
        "a",
        "antidisestablishmentarianism",
        "beautifications",
        "characteristically",
        "deterministically",
        "electroencephalography",
        "familiarisation",
        "gastrointestinal",
        "heterogeneousness",
        "incomprehensibility",
        "justifications",
        "knowledgeable",
        "lexicographically",
        "microarchitectures",
        "nondeterministically",
        "organizationally",
        "phenomenologically",
        "quantifications",
        "representationally",
        "straightforwardness",
        "telecommunications",
        "uncontrollability",
        "vulnerabilities",
        "wholeheartedly",
        "xylophonically",
        "youthfulness",
        "zoologically"
    };
    char *right[] = {
        "",
        "a",
        "the",
        "quick",
        "brown",
        "dog",
        "jumps",
        "over",
        "lazy",
        "fox",
        "get",
        "rid",
        "of",
        "windows",
        "and",
        "install",
        "linux"
    };
    int i, j, pos;
    char *ppos;

    for (i = 0; i < sizeof(left)/sizeof(*left); i++) {
        for(j = 0; j < sizeof(right)/sizeof(*right); j++) {
            pos = any(left[i], right[j]);
            ppos = strpbrk(left[i], right[j]);
            printf("finds one of [%s] in [%s]: %d", right[j], left[i], pos);
            if ((pos != -1 && left[i]+pos != ppos) ||
                (pos == -1 && ppos != NULL))
                printf(" -- failed!\n");
            else
                printf("\n");
        }
    }

    return 0;
}


/* end of 2-05-2.c */
