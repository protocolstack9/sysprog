/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 2-1A (p.36): Write a program to determine the ranges of char, short, int and
 *              long variables, both signed and unsigned, by printing
 *              appropriate values from standard headers and by direct
 *              computation. Harder if you compute them:
 *
 * The max values of unsigned types can be calculated by converting -1 to those
 * types and this is guaranteed to work on any conforming implementation. Those
 * of signed types are more difficult to compute. This code assumes that
 * integer overflow traps and signals SIGFPE, or is silently wrapped around.
 * Strictly speaking, using longjmp in a signal handler for SIGFPE is
 * prohibitted by the standard, which constitutes another assumption here.
 * The idea is borrowed from enquire.c by Steven Pemberton.
 */

#include <stdio.h>
#include <signal.h>
#include <setjmp.h>

#define getmax(r, type)          \
    do {                         \
        type i, max;             \
        max = 0;                 \
        i = 1;                   \
        if (setjmp(buf) == 0)    \
            while (i > max) {    \
                max = i;         \
                i = i*2 + 1;     \
            }                    \
        *(r) = max;              \
    } while(0)

#define getmin(r, type, max)      \
    do {                          \
        type min;                 \
        min = -(max);             \
        if (setjmp(buf) == 0)     \
            if (min - 1 < min)    \
                min--;            \
        *(r) = min;               \
    } while(0)

jmp_buf buf;

void trap(int ignored)
{
    signal(SIGFPE, trap);
    longjmp(buf, 1);    /* assumed to work */
}

main()
{
    if (setjmp(buf) == 0) {    /* for unexpected signal */
        signal(SIGFPE, trap);

        /* signed types */
        {    /* char, signed char */
            char charmin, charmax;
            signed char scharmin, scharmax;

            if ((char)-1 > 0) {    /* char is unsigned */
                printf("CHAR_MIN: %d, CHAR_MAX: %u\n", 0, (unsigned char)-1);
                getmax(&scharmax, signed char);
                getmin(&scharmin, signed char, scharmax);
            } else {    /* char is signed */
                getmax(&charmax, char);
                getmin(&charmin, char, charmax);
                printf("CHAR_MIN: %d, CHAR_MAX: %d\n", charmin, charmax);
                scharmax = charmax;
                scharmin = charmin;
            }
            printf("SCHAR_MIN: %d, SCHAR_MAX: %d\n", scharmin, scharmax);
        }

        {    /* short */
            short shrtmin, shrtmax;

            getmax(&shrtmax, short);
            getmin(&shrtmin, short, shrtmax);

            printf("SHRT_MIN: %d, SHRT_MAX: %d\n", shrtmin, shrtmax);
        }

        {    /* int */
            int intmin, intmax;

            getmax(&intmax, int);
            getmin(&intmin, int, intmax);
            printf("INT_MIN: %d, INT_MAX: %d\n", intmin, intmax);
        }

        {    /* long int */
            long int longmin, longmax;

            getmax(&longmax, long int);
            getmin(&longmin, long int, longmax);
            printf("LONG_MIN: %ld, LONG_MAX: %ld\n", longmin, longmax);
        }

        /* unsigned types */
        printf("UCHAR_MAX: %u\n", (unsigned)(unsigned char)-1);
        printf("USHRT_MAX: %hu\n", (unsigned short)-1);
        printf("UINT_MAX: %u\n", (unsigned)-1);
        printf("ULONG_MAX: %lu\n", (unsigned long)-1);
    } else
        printf("unexpected signal raised!\n");

    return 0;
}


/* end of 2-01-a-2.c */
