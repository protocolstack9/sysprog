/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-12
 *
 * 2-3 (p.46): Write the function htoi(s), which converts a string of
 *             hexadecimal digits (including an optional 0x or 0X) into its
 *             equivalent integer value. The allowable digits are 0 through 9, a
 *             through f, and A through F.
 *
 * In fact, the break statement should be used here since it is not covered yet.
 * Removing the break statement requires an additional condition variable to be
 * introduced for controlling the loop.
 *
 * Addition to replacing the if-else chain with a switch statement in order to
 * improve the answer, it can be much more simplified by using facilities from
 * the standard library.
 */

#include <stdio.h>

int htoi(char s[])
{
    int i, n;

    i = 0;

    if (s[i] == '0') {
        ++i;
        if (s[i] == 'x' || s[i] == 'X')
            ++i;
    }

    n = 0;
    while (s[i] != '\0') {
        n = n * 16;
        if (s[i] == 'A' || s[i] == 'a')
            n = n + 10;
        else if (s[i] == 'B' || s[i] == 'b')
            n = n + 11;
        else if (s[i] == 'C' || s[i] == 'c')
            n = n + 12;
        else if (s[i] == 'D' || s[i] == 'd')
            n = n + 13;
        else if (s[i] == 'E' || s[i] == 'e')
            n = n + 14;
        else if (s[i] == 'F' || s[i] == 'f')
            n = n + 15;
        else if (s[i] >= '0' && s[i] <= '9')
            n = n + (s[i] - '0');
        else    /* unrecognized character */
            break;
        ++i;
    }

    return n;
}

main()
{
    printf("%d\n", htoi("0xFF"));    /* 255 */
    printf("%d\n", htoi("0XFF"));    /* 255 */
    printf("%d\n", htoi("FF"));      /* 255 */
    printf("%d\n", htoi("7FFF"));    /* 32767 */
    printf("%d\n", htoi("0100"));    /* 256 */
    printf("%d\n", htoi("0x1"));     /* 1 */
    printf("%d\n", htoi("0XA"));     /* 10 */
    printf("%d\n", htoi("0xCBE"));   /* 3262 */
    printf("%d\n", htoi("abc"));     /* 2748 */
    printf("%d\n", htoi("def"));     /* 3567 */
    printf("%d\n", htoi("1234"));    /* 4660 */
    printf("%d\n", htoi("5678"));    /* 22136 */
    printf("%d\n", htoi("DAD"));     /* 3501 */

    return 0;
}


/* end of 2-03-1.c */
