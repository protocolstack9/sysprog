/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 2-4 (p.46): Write an alternate version of squeeze(s1,s2) that deletes each
 *             character in the string s1 that matches any character in the
 *             string s2.
 *
 * The approach used in this answer may not be efficient compared to a table-
 * based approach when the second string argument is very long; the table-based
 * approach is used to check the results.
 *
 * The test method used here is borrowed from Richard Heathfield's and I added
 * a check using a table-based approach to see if squeeze() works well.
 */

#include <limits.h>
#include <stdio.h>
#include <string.h>

/* squeeze() from K&R2 */
void knr_squeeze(char s[], int c)
{
    int i, j;

    for (i = j = 0; s[i] != '\0'; i++)
        if (s[i] != c)
            s[j++] = s[i];
    s[j] = '\0';
}

void squeeze(char *s1, char *s2)
{
    while (*s2) {
        knr_squeeze(s1, *s2);
        s2++;
    }
}

main()
{
    char *left[] = {
        "",
        "a",
        "antidisestablishmentarianism",
        "beautifications",
        "characteristically",
        "deterministically",
        "electroencephalography",
        "familiarisation",
        "gastrointestinal",
        "heterogeneousness",
        "incomprehensibility",
        "justifications",
        "knowledgeable",
        "lexicographically",
        "microarchitectures",
        "nondeterministically",
        "organizationally",
        "phenomenologically",
        "quantifications",
        "representationally",
        "straightforwardness",
        "telecommunications",
        "uncontrollability",
        "vulnerabilities",
        "wholeheartedly",
        "xylophonically",
        "youthfulness",
        "zoologically"
    };
    char *right[] = {
        "",
        "a",
        "the",
        "quick",
        "brown",
        "dog",
        "jumps",
        "over",
        "lazy",
        "fox",
        "get",
        "rid",
        "of",
        "windows",
        "and",
        "install",
        "linux"
    };
    int i, j;
    char buf[32];

    for (i = 0; i < sizeof(left)/sizeof(*left); i++) {
        for(j = 0; j < sizeof(right)/sizeof(*right); j++) {
            strcpy(buf, left[i]);
            squeeze(buf, right[j]);
            printf("[%s] - [%s] = [%s]", left[i], right[j], buf);
            {    /* checks if squeeze() works well */
                char *p;
                char removed[UCHAR_MAX+1] = { 0, };

                for (p = right[j]; *p; p++)
                    removed[(unsigned char)*p] = 1;
                for (p = left[i]; *p; p++)
                    if ((removed[(unsigned char)*p] && strchr(buf, *p)) ||
                        (!removed[(unsigned char)*p] && !strchr(buf, *p))) {
                        printf(" -- failed!\n");
                        break;
                    }
                if (*p == '\0')
                    printf("\n");
            }
        }
    }

    return 0;
}


/* end of 2-04-3.c */
