/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 2-1A (p.36): Write a program to determine the ranges of char, short, int and
 *              long variables, both signed and unsigned, by printing
 *              appropriate values from standard headers and by direct
 *              computation. Harder if you compute them:
 *
 * The values printed by this answer can be directly computed if some
 * assumptions on integer types are satisfied.
 */

#include <stdio.h>
#include <limits.h>

main()
{
    /* char */
    if (CHAR_MIN == 0)    /* char is unsigned */
        printf("CHAR_MIN: %u, CHAR_MAX: %u\n", (unsigned)CHAR_MIN,
               (unsigned)CHAR_MAX);
    else
        printf("CHAR_MIN: %d, CHAR_MAX: %d\n", CHAR_MIN, CHAR_MAX);

    /* signed types */
    printf("SCHAR_MIN: %d, SCHAR_MAX: %d\n", SCHAR_MIN, SCHAR_MAX);
    printf("SHRT_MIN: %d, SHRT_MAX: %d\n", SHRT_MIN, SHRT_MAX);
    printf("INT_MIN: %d, INT_MAX: %d\n", INT_MIN, INT_MAX);
    printf("LONG_MIN: %ld, LONG_MAX: %ld\n", LONG_MIN, LONG_MAX);

    /* unsigned types */
    printf("UCHAR_MAX: %u\n", (unsigned)UCHAR_MAX);
    printf("USHRT_MAX: %u\n", (unsigned)USHRT_MAX);
    printf("UINT_MAX: %u\n", UINT_MAX);
    printf("ULONG_MAX: %lu\n", ULONG_MAX);

    return 0;
}


/* end of 2-01-a-1.c */
