/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 2-10 (p.52): Rewrite the function lower, which converts upper case letter to
 *              lower case, with a conditional expression instead of if-else.
 *
 * As explained in the text, note that the approach used below and in the text
 * is not portable. A portable approach includes using mapping tables for
 * lower() and other similar functions.
 */

#include <limits.h>
#include <stdio.h>

int lower(int c)
{
    return (c >= 'A' && c <= 'Z')? c + 'a' - 'A': c;
}

/* lower() from K&R2 for comparison */
int knr_lower(int c)
{
    if (c >= 'A' && c <= 'Z')
        return c + 'a' - 'A';
    else
        return c;
}

main()
{
    int i;
    int n, o;

    for (i = 0; i < UCHAR_MAX; i++) {
        n = lower(i);
        o = knr_lower(i);
        if (n != o)
            printf("failed for %d; %d should be %d\n", i, n, o);
    }

    return 0;
}


/* end of 2-10.c */
