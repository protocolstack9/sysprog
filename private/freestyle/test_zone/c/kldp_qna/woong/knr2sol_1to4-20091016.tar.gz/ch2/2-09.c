/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 2-9 (p.51): In a two's complement number system, x &= (x-1) deletes the
 *             rightmost 1-bit in x. Explain why. Use this observation to write
 *             a faster version of bitcount.
 *
 * We need to consider how the given expression works for three cases:
 * - x is positive and odd;
 * - x is positive and even and
 * - x is zero;
 * note that applying the bitwise operators to negative values is not considered
 * to be portable (this is why the parameter of bitcount() is unsigned), we do
 * not need to care other cases; Performing the bitwise AND operation with 0 and
 * -1 is assumed to work as expected, which means it is assumed not to touch any
 * trap representation.
 *
 * 1) When x is positive and odd
 *
 * it is straight-forward to understand how the given expression deletes the
 * rightmost 1-bit of x. Since x is odd, its rightmost bit is set and (x-1) has
 * its rightmost bit unset with other bits unchanged. In fact, subtracting 1
 * from an odd number alone has the effect to delete its rightmost 1-bit.
 *
 * 2) When x is positive and even
 *
 * x has a 1-bit somewhere other than in the rightmost bit. (x-1) makes the
 * 1-bit unset and other bits right to it set as can be seen in 1000 - 1 = 0111.
 * Applying the bitwise AND operator to these results in setting to zero only
 * the rightmost 1-bit of x.
 *
 * 3) When x is 0
 *
 * x has no bit set to 1, so the result should be also zero. Regardless of the
 * bitwise representation of (x-1), x &= (x-1) always results in zero since x
 * itself is zero.
 */

#include <stdio.h>

int bitcount(unsigned x)
{
    int b;

    b = 0;
    while (x > 0) {
        b++;
        x &= (x-1);
    }

    return b;
}

/* bitcount() from K&R2 for comparison */
int knr_bitcount(unsigned x)
{
    int b;

    for (b = 0; x != 0; x >>= 1)
        if (x & 01)
            b++;

    return b;
}

main()
{
    int n, o;
    unsigned i;

    for (i = 0; i < 1000; i++) {
        n = bitcount(i);
        o = knr_bitcount(i);
        if (n != o)
            printf("failed for %u; %d should be %d\n", i, n, o);
    }

    return 0;
}


/* end of 2-09.c */
