/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 2-4 (p.46): Write an alternate version of squeeze(s1,s2) that deletes each
 *             character in the string s1 that matches any character in the
 *             string s2.
 *
 * The approach used in this answer may not be efficient compared to a table-
 * based approach when the second string argument is very long; the table-based
 * approach is used to check the results.
 *
 * In general, C programmers perfer using the pointer arithmetic to using the
 * array indexing.
 *
 * The test method used here is borrowed from Richard Heathfield's and I added
 * a check using a table-based approach to see if squeeze() works well.
 */

#include <limits.h>
#include <stdio.h>
#include <string.h>

void squeeze(char s1[], char s2[])
{
    int i, j;

    i = 0;
    while (s1[i] != '\0') {
        for (j = 0; s2[j] != '\0' && s1[i] != s2[j]; j++)
            ;
        if (s2[j] != '\0') {    /* found */
            for (j = i; s1[j] != '\0'; j++)
                s1[j] = s1[j+1];    /* note that null also copied */
        } else
            i++;    /* i++ must be in the else branch */
    }
}

main()
{
    char *left[] = {
        "",
        "a",
        "antidisestablishmentarianism",
        "beautifications",
        "characteristically",
        "deterministically",
        "electroencephalography",
        "familiarisation",
        "gastrointestinal",
        "heterogeneousness",
        "incomprehensibility",
        "justifications",
        "knowledgeable",
        "lexicographically",
        "microarchitectures",
        "nondeterministically",
        "organizationally",
        "phenomenologically",
        "quantifications",
        "representationally",
        "straightforwardness",
        "telecommunications",
        "uncontrollability",
        "vulnerabilities",
        "wholeheartedly",
        "xylophonically",
        "youthfulness",
        "zoologically"
    };
    char *right[] = {
        "",
        "a",
        "the",
        "quick",
        "brown",
        "dog",
        "jumps",
        "over",
        "lazy",
        "fox",
        "get",
        "rid",
        "of",
        "windows",
        "and",
        "install",
        "linux"
    };
    int i, j;
    char buf[32];

    for (i = 0; i < sizeof(left)/sizeof(*left); i++) {
        for(j = 0; j < sizeof(right)/sizeof(*right); j++) {
            strcpy(buf, left[i]);
            squeeze(buf, right[j]);
            printf("[%s] - [%s] = [%s]", left[i], right[j], buf);
            {    /* checks if squeeze() works well */
                char *p;
                char removed[UCHAR_MAX+1] = { 0, };

                for (p = right[j]; *p; p++)
                    removed[(unsigned char)*p] = 1;
                for (p = left[i]; *p; p++)
                    if ((removed[(unsigned char)*p] && strchr(buf, *p)) ||
                        (!removed[(unsigned char)*p] && !strchr(buf, *p))) {
                        printf(" -- failed!\n");
                        break;
                    }
                if (*p == '\0')
                    printf("\n");
            }
        }
    }

    return 0;
}


/* end of 2-04-1.c */
