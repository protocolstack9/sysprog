/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-12
 *
 * 2-2 (p.42): Write a loop equivalent to the for loop above without using && or
 *             ||. (The original loop is given in the commented-out code below.)
 *
 * The solution given here is, I think, the most typical one without using the
 * break statement. The break statement can simplify the answer significantly.
 */

#include <stdio.h>

#if 0    /* original code */
int getline(char s[],int lim)
{
    int c, i;

    for (i = 0; i < lim-1 && (c=getchar())!=EOF && c!='\n'; ++i)
        s[i] = c;
    if (c == '\n') {
        s[i] = c;
        ++i;
    }
    s[i] = '\0';
    return i;
}
#endif

int getline(char s[], int lim)
{
    int escape;
    int c, i;

    i = 0;
    escape = 0;
    while (escape == 0) {
        if (i >= lim-1)
            escape = 1;
        else if ((c = getchar()) == EOF)
            escape = 1;
        else if (c == '\n')
            escape = 1;
        else {
            s[i] = c;
            ++i;    /* i increases only when character stored */
        }
    }
    if (c == '\n') {
        s[i] = c;
        ++i;
    }
    s[i] = '\0';
    return i;
}

main()
{
    /* main has nothing to do */

    return 0;
}


/* end of 2-02-1.c */
