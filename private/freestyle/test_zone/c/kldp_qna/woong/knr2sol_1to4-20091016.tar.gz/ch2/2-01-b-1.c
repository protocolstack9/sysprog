/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 2-1B (p.36): Write a program to determine the ranges of char, short, int and
 *              long variables, both signed and unsigned, by printing
 *              appropriate values from standard headers and by direct
 *              computation. Harder if you compute them: (2-1A) determine the
 *              ranges of the various floating-point types.
 *
 * The values printed by this answer can be directly computed if some
 * assumptions on floating types are satisfied.
 */

#include <stdio.h>
#include <float.h>

main()
{
    printf("FLT_RADIX: %d\n", (int)FLT_RADIX);
    printf("FLT_MIN: %e, FLT_MAX: %e\n", FLT_MIN, FLT_MAX);
    printf("DBL_MIN: %e, DBL_MAX: %e\n", DBL_MIN, DBL_MAX);
    printf("LDBL_MIN: %Le, LDBL_MAX: %Le\n", LDBL_MIN, LDBL_MAX);

    return 0;
}


/* end of 2-01-b-1.c */
