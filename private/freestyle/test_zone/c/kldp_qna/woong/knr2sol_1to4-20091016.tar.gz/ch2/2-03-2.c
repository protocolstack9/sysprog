/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 2-3 (p.46): Write the function htoi(s), which converts a string of
 *             hexadecimal digits (including an optional 0x or 0X) into its
 *             equivalent integer value. The allowable digits are 0 through 9, a
 *             through f, and A through F.
 */

#include <ctype.h>
#include <string.h>

#include <stdio.h>

int htoi(char *s)
{
    int n;
    char *p, *digit = "0123456789ABCDEF";

    if (*s == '0') {
        s++;
        if (*s == 'x' || *s == 'X')
            s++;
    }

    n = 0;
    while (*s) {
        n *= 16;
        p = strchr(digit, toupper((unsigned char)*s));
        if (p)
            n += (p - digit);
        else    /* unrecognized character */
            break;
        s++;
    }

    return n;
}

main()
{
    printf("%d\n", htoi("0xFF"));    /* 255 */
    printf("%d\n", htoi("0XFF"));    /* 255 */
    printf("%d\n", htoi("FF"));      /* 255 */
    printf("%d\n", htoi("7FFF"));    /* 32767 */
    printf("%d\n", htoi("0100"));    /* 256 */
    printf("%d\n", htoi("0x1"));     /* 1 */
    printf("%d\n", htoi("0XA"));     /* 10 */
    printf("%d\n", htoi("0xCBE"));   /* 3262 */
    printf("%d\n", htoi("abc"));     /* 2748 */
    printf("%d\n", htoi("def"));     /* 3567 */
    printf("%d\n", htoi("1234"));    /* 4660 */
    printf("%d\n", htoi("5678"));    /* 22136 */
    printf("%d\n", htoi("DAD"));     /* 3501 */

    return 0;
}


/* end of 2-03-2.c */
