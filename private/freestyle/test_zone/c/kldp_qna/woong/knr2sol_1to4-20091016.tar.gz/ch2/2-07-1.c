/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 2-7 (p.49): Write a function invert(x,p,n) that returns x with the n bits
 *             that begin at position p inverted (i.e., 1 changed into 0 and
 *             vice versa), leaving the others unchanged.
 *
 * As explained in the answer to the problem 2-6, ((1U << n) - 1) can be
 * replaced with (~(0U << n)).
 *
 * "n bits from the position p" refers to different sets of bits depending on
 * the direction (left or right) of counting bits. This answer follows how an
 * example given in the text handles them.
 *
 * This answer shows a very straight-forward approach. A simpler way is to use
 * the property of the xor operation. Xor-ing a value with another value whose
 * bits are all set makes the inverted value of the former, and xor-ing with
 * a value whose bits are all unset results in the or operation:
 *
 *     0 (xor) 1 = 1    |    (invert) 0 = 1
 *     1 (xor) 1 = 0    |    (invert) 1 = 0
 *     0 (xor) 0 = 0    |    0 (or) 0 = 0
 *     0 (xor) 1 = 1    |    0 (or) 1 = 1
 *
 * which are exactly wanted for inverting only a part of a value.
 */

#include <stdio.h>

unsigned invert(unsigned x, int p, int n)
{
    unsigned mask = ((1U << n) - 1) << (p + 1 - n);
    return (x & ~mask) | (~(x & mask) & mask);
}

main()
{
    printf("%u\n", invert(170, 2, 3));
        /* 0...010101[010] => 0...010101[101] = 173 */
    printf("%u\n", invert(170, 3, 4));
        /* 0...01010[1010] => 0...01010[0101] = 165 */
    printf("%u\n", invert(170, 6, 3));
        /* 0...01[010]1010 => 0...01[101]1010 = 218 */
    printf("%u\n", invert(170, 6, 6));
        /* 0...01[010101]0 => 0...01[101010]0 = 212 */
    printf("%u\n", invert(170, 7, 8));
        /* 0...0[10101010] => 0...0[01010101] = 85 */

    return 0;
}


/* end of 2-07-1.c */
