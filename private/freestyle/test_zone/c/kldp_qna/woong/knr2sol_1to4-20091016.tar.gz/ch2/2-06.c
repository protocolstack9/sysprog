/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 2-6 (p.49): Write a function setbits(x,p,n,y) that returns x with the n bits
 *             that begin at position p set to the rightmost n bits of y,
 *             leaving the other bits unchanged.
 *
 * There are many ways to get a bit-pattern; for example, getting a bit-pattern
 * whose rightmost n bits are set can be represented as ((1U << n) - 1) given
 * below or as (~(~0U << n)) given in the book. Note when shifting to the left
 * by (p + 1 - n) bits is performed to get the rightmost n bits from y and to
 * set the n bits of x at the position p.
 *
 * "n bits from the position p" refers to different sets of bits depending on
 * the direction (left or right) of counting bits. This answer follows how an
 * example given in the text handles them.
 */

#include <stdio.h>

unsigned setbits(unsigned x, int p, int n, unsigned y)
{
    return (x & ~(((1U << n) - 1) << (p + 1 - n))) |
           ((y & ((1U << n) - 1)) << (p + 1 - n));
}

main()
{
    printf("%u\n", setbits(0, 3, 4, ~0U));
        /* 0...0[0000] 1...1[1111] => 0...0[1111] = 15 */
    printf("%u\n", setbits(170, 5, 4, ~0U));
        /* 0...10[1010]10  1...1[1111] => 0...10[1111]10 = 190 */
    printf("%u\n", setbits(170, 5, 4, 0));
        /* 0...10[1010]10  0...0[0000] => 0...10[0000]10 = 130 */
    printf("%u\n", setbits(170, 7, 4, ~0U));
        /* 0...0[1010]1010 1...1[1111] => 0...0[1111]1010 = 250 */
    printf("%u\n", setbits(170, 3, 4, 0));
        /* 0...01010[1010] 0...0[0000] => 0...01010[0000] = 160 */

    return 0;
}


/* end of 2-06.c */
