/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 2-4 (p.46): Write an alternate version of squeeze(s1,s2) that deletes each
 *             character in the string s1 that matches any character in the
 *             string s2.
 *
 * The approach used in this answer may not be efficient compared to a table-
 * based approach when the second string argument is very long; the table-based
 * approach is used to check the results.
 *
 * It is also possible to use squeeze() from K&R2 to implement the alternate
 * version.
 *
 * One might notice that, by introducing another pointer for the place into
 * which characters are copied it is possible to reduce the number of
 * characters copied when dropping a character that matches one of the second
 * string. That is true, but it does not bring huge improvement on performance
 * unless squeeze() is invoked very many times or on a set of very long strings.
 *
 * The test method used here is borrowed from Richard Heathfield's and I added
 * a check using a table-based approach to see if squeeze() works well.
 */

#include <limits.h>
#include <stdio.h>
#include <string.h>

void squeeze(char s1[], char s2[])
{
    char *p;

    while (*s1) {
        for (p = s2; *p && *s1 != *p; p++)
            continue;
        if (*p != '\0') {    /* found */
            for (p = s1; *p; p++)
                p[0] = p[1];    /* note that null also copied */
        } else
            s1++;    /* s1 must be in the else branch */
    }
}

main()
{
    char *left[] = {
        "",
        "a",
        "antidisestablishmentarianism",
        "beautifications",
        "characteristically",
        "deterministically",
        "electroencephalography",
        "familiarisation",
        "gastrointestinal",
        "heterogeneousness",
        "incomprehensibility",
        "justifications",
        "knowledgeable",
        "lexicographically",
        "microarchitectures",
        "nondeterministically",
        "organizationally",
        "phenomenologically",
        "quantifications",
        "representationally",
        "straightforwardness",
        "telecommunications",
        "uncontrollability",
        "vulnerabilities",
        "wholeheartedly",
        "xylophonically",
        "youthfulness",
        "zoologically"
    };
    char *right[] = {
        "",
        "a",
        "the",
        "quick",
        "brown",
        "dog",
        "jumps",
        "over",
        "lazy",
        "fox",
        "get",
        "rid",
        "of",
        "windows",
        "and",
        "install",
        "linux"
    };
    int i, j;
    char buf[32];

    for (i = 0; i < sizeof(left)/sizeof(*left); i++) {
        for(j = 0; j < sizeof(right)/sizeof(*right); j++) {
            strcpy(buf, left[i]);
            squeeze(buf, right[j]);
            printf("[%s] - [%s] = [%s]", left[i], right[j], buf);
            {    /* checks if squeeze() works well */
                char *p;
                char removed[UCHAR_MAX+1] = { 0, };

                for (p = right[j]; *p; p++)
                    removed[(unsigned char)*p] = 1;
                for (p = left[i]; *p; p++)
                    if ((removed[(unsigned char)*p] && strchr(buf, *p)) ||
                        (!removed[(unsigned char)*p] && !strchr(buf, *p))) {
                        printf(" -- failed!\n");
                        break;
                    }
                if (*p == '\0')
                    printf("\n");
            }
        }
    }

    return 0;
}


/* end of 2-04-2.c */
