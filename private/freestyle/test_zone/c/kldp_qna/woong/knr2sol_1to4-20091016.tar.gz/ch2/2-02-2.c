/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-12
 *
 * 2-2 (p.42): Write a loop equivalent to the for loop above without using && or
 *             ||. (The original loop is given in the commented-out code below.)
 *
 * Since the problem says only those two logical operators must not be used, one
 * can hire trickier approaches such as using the comma operator in the
 * controlling expression of the for loop; A || B logically matches (A)? 1: B,
 * and A && B does (A)? B: 0.
 */

#include <stdio.h>

#if 0    /* original code */
int getline(char s[],int lim)
{
    int c, i;

    for (i = 0; i < lim-1 && (c=getchar())!=EOF && c!='\n'; ++i)
        s[i] = c;
    if (c == '\n') {
        s[i] = c;
        ++i;
    }
    s[i] = '\0';
    return i;
}
#endif

int getline(char s[], int lim)
{
    int c, i;

    for (i = 0; i < lim-1; i++) {
        if ((c = getchar()) == EOF)
            break;
        else if (c == '\n')
            break;
        s[i] = c;
    }
    if (c == '\n') {
        s[i] = c;
        i++;
    }
    s[i] = '\0';
    return i;
}

main()
{
    /* main has nothing to do */

    return 0;
}


/* end of 2-02-2.c */
