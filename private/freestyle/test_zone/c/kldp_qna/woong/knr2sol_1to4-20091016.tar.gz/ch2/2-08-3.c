/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 2-8 (p.49): Write a function rightrot(x,n) that returns the value of the
 *             integer x rotated to the right by n positions.
 *
 * This answer determines the number of bits in the unsigned type empirically
 * so works on an implementation where padding bits are used.
 *
 * Note that it is checked if n is 0 after the remainder operation, since
 * shifting to the left would cause undefined behavior without that test.
 */

#include <stdio.h>

unsigned rightrot(unsigned x, int n)
{
    int t;
    unsigned i;

    i = 1;
    t = 0;
    while (i != 0) {
        i <<= 1;
        t++;
    }

    n %= t;

    return (n)? (x << (t - n)) | (x >> n): x;
}

main()
{
    /* results interpreted with assumption that unsigned occupies 32 bits;
       rightrot() does not need such assumption to work */
    printf("%u\n", rightrot(3435965098U, 5));
        /* 1100 1100 1100 1100 1010 1010 101[0 1010] =>
               [0101 0]110 0110 0110 0110 0101 0101 0101 = 1449551189 */
    printf("%u\n", rightrot(3435965098U, 16));
        /* 1100 1100 1100 1100 [1010 1010 1010 1010] =>
               [1010 1010 1010 1010] 1100 1100 1100 1100 = 2863320268 */
    printf("%u\n", rightrot(3435965098U, 31));
        /* 1[100 1100 1100 1100 1010 1010 1010 1010] =>
               [1001 1001 1001 1001 0101 0101 0101 010]1 = 2576962901 */
    printf("%u\n", rightrot(3435965098U, 32));
        /* [1100 1100 1100 1100 1010 1010 1010 1010] =>
               [1100 1100 1100 1100 1010 1010 1010 1010] = 3435965098 */
    printf("%u\n", rightrot(3435965098U, 37));
        /* (after 32 bits rotated)
           1100 1100 1100 1100 1010 1010 101[0 1010] =>
               [0101 0]110 0110 0110 0110 0101 0101 0101 = 1449551189 */

    return 0;
}


/* end of 2-08-3.c */
