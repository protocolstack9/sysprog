/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 2-8 (p.49): Write a function rightrot(x,n) that returns the value of the
 *             integer x rotated to the right by n positions.
 *
 * A explained in the answer to the problem 2-6, ((1U << n) - 1) can be
 * replaced with (~(0U << n)).
 *
 * This answer carefully avoids explicit calculation of the number of bits
 * in the unsigned type like sizeof(unsigned) * CHAR_BIT since an implementation
 * is allowed to have in the type padding bits that do not contribute values.
 * Instead, this approach imposes on the answer a limit that the number of bits
 * to rotate is not allowed to exceed the number of bits in the unsigned type.
 *
 * Also note that no overflow occurs when multiplying x with a properly
 * calculated power of 2 for left shifting, because of the wrap-around property
 * of unsigned types.
 */

#include <stdio.h>

unsigned rightrot(unsigned x, int n)
{
    return (x * ((~((1U << n) - 1) >> n) + 1)) | (x >> n);
}

main()
{
    /* results interpreted with assumption that unsigned occupies 32 bits;
       rightrot() does not need such assumption to work */
    printf("%u\n", rightrot(3435965098U, 5));
        /* 1100 1100 1100 1100 1010 1010 101[0 1010] =>
               [0101 0]110 0110 0110 0110 0101 0101 0101 = 1449551189 */
    printf("%u\n", rightrot(3435965098U, 16));
        /* 1100 1100 1100 1100 [1010 1010 1010 1010] =>
               [1010 1010 1010 1010] 1100 1100 1100 1100 = 2863320268 */
    printf("%u\n", rightrot(3435965098U, 31));
        /* 1[100 1100 1100 1100 1010 1010 1010 1010] =>
               [1001 1001 1001 1001 0101 0101 0101 010]1 = 2576962901 */

    return 0;
}


/* end of 2-08-1.c */
