/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 3-2 (p.60): Write a function escape(s,t) that converts characters like
 *             newline and tab into visible escape sequences like \n and \t as
 *             it copies the string t to s. Use a switch. Write a function for
 *             the other direction as well, converting escape sequences into the
 *             real characters.
 *
 * Characters to be escaped or unescaped are: \a, \b, \f, \n, \r, \t, \v, \\,
 * \?, \' and \" (octal and hexadecimal sequences are not supported).
 */

#include <stdio.h>

void escape(char s[], char t[])
{
    int i, j;

    j = 0;
    for (i = 0; t[i] != '\0'; i++) {
        switch(t[i]) {
            case '\a':
                s[j++] = '\\';
                s[j++] = 'a';
                break;
            case '\b':
                s[j++] = '\\';
                s[j++] = 'b';
                break;
            case '\f':
                s[j++] = '\\';
                s[j++] = 'f';
                break;
            case '\n':
                s[j++] = '\\';
                s[j++] = 'n';
                break;
            case '\r':
                s[j++] = '\\';
                s[j++] = 'r';
                break;
            case '\t':
                s[j++] = '\\';
                s[j++] = 't';
                break;
            case '\v':
                s[j++] = '\\';
                s[j++] = 'v';
                break;
            case '\\':
                s[j++] = '\\';
                s[j++] = '\\';
                break;
            case '\?':
                s[j++] = '\\';
                s[j++] = '?';
                break;
            case '\'':
                s[j++] = '\\';
                s[j++] = '\'';
                break;
            case '\"':
                s[j++] = '\\';
                s[j++] = '"';
                break;
            default:
                s[j++] = t[i];
                break;
        }
    }
    s[j] = '\0';
}

void unescape(char s[], char t[])
{
    int i, j;

    j = 0;
    for (i = 0; t[i] != '\0'; i++) {
        switch(t[i]) {
            case '\\':
                switch(t[++i]) {
                    case 'a':
                        s[j++] = '\a';
                        break;
                    case 'b':
                        s[j++] = '\b';
                        break;
                    case 'f':
                        s[j++] = '\f';
                        break;
                    case 'n':
                        s[j++] = '\n';
                        break;
                    case 'r':
                        s[j++] = '\r';
                        break;
                    case 't':
                        s[j++] = '\t';
                        break;
                    case 'v':
                        s[j++] = '\v';
                        break;
                    case '\\':
                        s[j++] = '\\';
                        break;
                    case '?':
                        s[j++] = '?';
                        break;
                    case '\'':
                        s[j++] = '\'';
                        break;
                    case '"':
                        s[j++] = '"';
                        break;
                    default:    /* unsupported escape sequence */
                        s[j++] = '\\';
                        s[j++] = t[i];
                        break;
                }
                break;
            default:
                s[j++] = t[i];
                break;
        }
    }
    s[j] = '\0';
}

main()
{
    char t[] = "\a\bcde\fghijklm\nopq\rs\tu\vwxyz\\\?\'\"";
    char s[sizeof(t)*2];
    char u[sizeof(s)];
    char v[] = "ab\\c\\d\\ef\\g\\h\\i\\j\\k\\l\\mn\\o\\p\\qr\\st\\uv\\w\\x\\y\\z"
               "\\#";
    char w[sizeof(v)];

    escape(s, t);
    printf("%s", s);
    unescape(u, s);
    if (strcmp(t, u) != 0)
        printf(" -- failed\n");
    else
        printf("\n");
    unescape(w, v);
    printf("%s", w);
    if (strcmp(w, v) != 0)
        printf(" -- failed\n");
    else
        printf("\n");

    return 0;
}


/* end of 3-02.c */
