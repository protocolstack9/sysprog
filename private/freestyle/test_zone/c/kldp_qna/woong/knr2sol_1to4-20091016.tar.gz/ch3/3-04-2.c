/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-14
 *
 * 3-4 (p.64): In a two's complement number representation, our version of itoa
 *             does not handle the largest negative number, that is, the value
 *             of n equal to -(2 ** (wordsize-1)) (where x ** y means x to the
 *             power y). Explain why not. Modify it to print that value
 *             correctly regardless of the machine on which it runs.
 *
 * The explanatory answer is given in 3-04-1.c.
 *
 * As said in 3-04-1.c, this answer assumes that integral division always
 * truncates, which is guaranteed by C99.
 *
 * There is another approach that takes advantage of the fact that unsigned
 * types never overflow and that works well except on some peculiar
 * implementations where INT_MAX == UINT_MAX.
 */

#include <string.h>

#include <stdio.h>
#include <limits.h>

/* reverse() from K&R2 */
void reverse(char s[])
{
    int c, i, j;

    for (i = 0, j = strlen(s)-1; i < j; i++, j--) {
        c = s[i];
        s[i] = s[j];
        s[j] = c;
    }
}

/* itoa() from K&R2 */
void knr_itoa(int n, char s[])
{
    int i, sign;

    if ((sign = n) < 0)    /* record sign */
        n = -n;            /* make n positive */
    i = 0;
    do {        /* generate digits in reverse order */
        s[i++] = n % 10 + '0';    /* get next digit */
    } while ((n /= 10) > 0);      /* delete it */
    if (sign < 0)
        s[i++] = '-';
    s[i] = '\0';
    reverse(s);
}

void itoa(int n, char s[])
{
    int i, sign;

    if ((sign = n) > 0)    /* makes negative rather than positive */
        n = -n;    /* no overflow */
    i = 0;
    do {    /* n remains negative in loop */
        s[i++] = '0' - (n % 10);    /* (n % 10) is zero or negative */
    } while ((n /= 10) != 0);    /* != instead of > since n is negative */
    if (sign < 0)
        s[i++] = '-';
    s[i] = '\0';
    reverse(s);
}

main()
{
    int i;
    char buf1[CHAR_BIT*sizeof(int)/3+1+1],
         buf2[CHAR_BIT*sizeof(int)/3+1+1];

    /* see 3-04-1.c for the infinite loop below */
    i = INT_MIN;
    while (1) {
        knr_itoa(i, buf1);    /* UB when i == INT_MIN */
        itoa(i, buf2);
        if (strcmp(buf1, buf2) != 0)
            printf("failed - knr_itoa() gives %s and itoa() gives %s for %d\n",
                   buf1, buf2, i);
        if (i % (INT_MAX / 500) == 0) {
            if (i < 0)
                printf("%.1f%% done\n", (double)(INT_MIN-i) * 50 / -INT_MAX);
            else
                printf("%.1f%% done\n", (double)i * 50 / INT_MAX + 50);
        }
        if (i == INT_MAX)
            break;
        i++;
    }

    return 0;
}


/* end of 3-04-2.c */
