/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 3-3 (p.63): Write a function expand(s1,s2) that expands shorthand notations
 *             like a-z in the string s1 into the equivalent complete list
 *             abc...xyz in s2. Allow for letters of either case and digits, and
 *             be prepared to handle cases like a-b-c and a-z0-9 and -a-z.
 *             Arrange that a leading or trailing - is taken literally.
 *
 * Some tricky cases to handle include "a-a" (which is expanded to "a" in this
 * answer), "z-a" and "a-9" (both of which are not expanded in this answer).
 * Changing code to expand "z-a" to "zyx...cba" can be achieved by changing the
 * direction of the loops that copy lower, upper and digit depending on s and e.
 *
 * Note how changing the while iteration to the for iteration interacts with use
 * of the continue statement and how pointers can be used to factor out the
 * common part within the loop.
 *
 * expand() can be more compact and probably more readable by making the
 * repeated code to inspect lower, upper and digit a function.
 */

#include <string.h>

#include <stdio.h>

void expand(const char *s1, char *s2)
{
    char lastc;
    const char *s, *e;
    const char *lower = "abcdefghijklmnopqrstuvwxyz",
               *upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
               *digit = "0123456789";

    lastc = '?';    /* ? is not expanded, so proper initializer */
    for (; *s1; lastc = *s1++) {
        if (*s1 == '-') {
            if ((s = strchr(lower, lastc)) != NULL &&
                (e = strchr(s, s1[1])) != NULL)
                ;    /* factored out below */
            else if ((s = strchr(upper, lastc)) != NULL &&
                     (e = strchr(s, s1[1])) != NULL)
                ;    /* factored out below */
            else if ((s = strchr(digit, lastc)) != NULL &&
                     (e = strchr(s, s1[1])) != NULL)
                ;    /* factored out below */
            else {
                *s2++ = *s1;
                continue;    /* does lastc = *s1++ */
            }
            /* *s1 already copied; so starts at s+1 */
            while (++s <= e)
                *s2++ = *s;
            s1++;
        } else {
            *s2++ = *s1;
        }
    }
    *s2 = '\0';
}

main()
{
    char *test[] = {
        "a-z",
        "A-Z",
        "0-9",
        "a-zA-Z0-9",
        "a-b-c",
        "0-3-9",
        "c-w",
        "3-7",
        "a-h-z",
        "-a-z-",
        "--a--z--0-90--9--",
        "z-a",
        "a-a",
        "-z-w-",
        "- alphabets are a-z -",
        "--",
        "-",
        ""
    };
    int i;
    char buf[100];

    for (i = 0; i < sizeof(test)/sizeof(test[0]); i++) {
        printf("\"%s\" expands to ", test[i]);
        expand(test[i], buf);
        printf("\"%s\"\n", buf);
    }

    return 0;
}


/* end of 3-03-2.c */
