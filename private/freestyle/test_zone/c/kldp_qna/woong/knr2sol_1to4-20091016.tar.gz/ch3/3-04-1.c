/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-14
 *
 * 3-4 (p.64): In a two's complement number representation, our version of itoa
 *             does not handle the largest negative number, that is, the value
 *             of n equal to -(2 ** (wordsize-1)) (where x ** y means x to the
 *             power y). Explain why not. Modify it to print that value
 *             correctly regardless of the machine on which it runs.
 *
 * When n is negative, itoa() negates it to make it positive remembering its
 * sign. Since in two's complement representation, there is no corresponding
 * positive number to the smallest negative one, that negation results in
 * overflow, after which all bets are off. On a widespread machine, negating
 * the smallest number gives the same negative value, which screws up converting
 * it to string representation [*].
 *
 * There are various ways to solve this problem. The method used in this answer
 * is the most portable despite its complexity. itoa() in this solution makes n
 * negative rather than positive and converts it to a string carefully. One
 * important thing to remember here is that C90 leaves the direction of rounding
 * for negative integral division as implementation-defined. To cope with this
 * variety, it checks the direction before conversion using this property: Given
 * r = x % y, the division has performed truncation if r is not zero and has the
 * same sign as x. Strictly speaking, an weird implementation can change between
 * truncation and rounding to -inf whenever negative integral division performs.
 * Or more plausibly, an implementation chooses truncation or rounding to -inf
 * for constant expressions and the other for non-constant expressions. This
 * answer, however, does not allow for such peculiarity for simplicity and uses
 * a constant expression for the check, which facilitates optimization; most
 * compilers would evaluate the check at translation-time, so avoid paying the
 * penalty of performance in getting the correct remainder and quotient in the
 * loop.
 *
 * If integral division is guaranteed to always truncate its results (as in
 * C99), the answer can be simplified.
 *
 * [*] To be precise, knr_itoa() below prints out '-' and a character whose code
 *     value is (INT_MIN % 10 + '0') that corresponds to '(' in many ASCII
 *     implementations. Since the controlling expression is given as
 *     ((n /= 10) > 0) instead of ((n /= 10) != 0), the do-while loop runs only
 *     once.
 */

#include <string.h>

#include <stdio.h>
#include <limits.h>

/* reverse() from K&R2 */
void reverse(char s[])
{
    int c, i, j;

    for (i = 0, j = strlen(s)-1; i < j; i++, j--) {
        c = s[i];
        s[i] = s[j];
        s[j] = c;
    }
}

/* itoa() from K&R2 */
void knr_itoa(int n, char s[])
{
    int i, sign;

    if ((sign = n) < 0)    /* record sign */
        n = -n;            /* make n positive */
    i = 0;
    do {        /* generate digits in reverse order */
        s[i++] = n % 10 + '0';    /* get next digit */
    } while ((n /= 10) > 0);      /* delete it */
    if (sign < 0)
        s[i++] = '-';
    s[i] = '\0';
    reverse(s);
}

void itoa(int n, char s[])
{
    int trunc;
    int i, r, sign;

    trunc = (-3 % 2 < 0);    /* negative div performs truncation? */

    if ((sign = n) > 0)    /* makes negative rather than positive */
        n = -n;    /* no overflow */
    i = 0;
    do {    /* n remains negative in loop */
        r = n % 10;
        s[i++] = '0' + ((trunc || r == 0)? -r: 10 - r);
        n /= 10;
        if (!trunc && r != 0)
            n += 1;
    } while (n != 0);    /* (n > 0) cannot be used since n is negative */
    if (sign < 0)
        s[i++] = '-';
    s[i] = '\0';
    reverse(s);
}

main()
{
    int i;
    char buf1[CHAR_BIT*sizeof(int)/3+1+1],
         buf2[CHAR_BIT*sizeof(int)/3+1+1];

    /* note that tries to loop over [INT_MIN, INT_MAX] like
           for (i = INT_MIN; i < INT_MAX; i++) ...
           for (i = INT_MIN; i < INT_MAX+1; i++) ...
           for (i = INT_MIN; i <= INT_MAX; i++) ...
           do { ... } while(i++ < INT_MAX);
       all cannot be reliably used due to overflow. Because it is allowed that
       INT_MAX == UINT_MAX == ULONG_MAX, employing an unsigned variable is not
       also helpful */
    i = INT_MIN;
    while (1) {
        knr_itoa(i, buf1);    /* UB when i == INT_MIN */
        itoa(i, buf2);
        if (strcmp(buf1, buf2) != 0)
            printf("failed - knr_itoa() gives %s and itoa() gives %s for %d\n",
                   buf1, buf2, i);
        if (i % (INT_MAX / 500) == 0) {
            if (i < 0)
                printf("%.1f%% done\n", (double)(INT_MIN-i) * 50 / -INT_MAX);
            else
                printf("%.1f%% done\n", (double)i * 50 / INT_MAX + 50);
        }
        if (i == INT_MAX)
            break;
        i++;
    }

    return 0;
}


/* end of 3-04-1.c */
