/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 3-3 (p.63): Write a function expand(s1,s2) that expands shorthand notations
 *             like a-z in the string s1 into the equivalent complete list
 *             abc...xyz in s2. Allow for letters of either case and digits, and
 *             be prepared to handle cases like a-b-c and a-z0-9 and -a-z.
 *             Arrange that a leading or trailing - is taken literally.
 *
 * Some tricky cases to handle include "a-a" (which is expanded to "a" in this
 * answer), "z-a" and "a-9" (both of which are not expanded in this answer).
 * Changing code to expand "z-a" to "zyx...cba" requires index() return two
 * pointers that point to the start and the end as s and e do in 3-03-2.c.
 * Depending on those pointers, the direction of copying lower, upper and digit
 * can be changed properly.
 */

#include <string.h>

#include <stdio.h>

const char *index(const char *tab[], int lastc, int nextc)
{
    const char *p, *r;

    while (*tab) {
        p = strchr(*tab, lastc);
        if (p && strchr(p, nextc))
            return p;
        tab++;
    }

    return NULL;
}

void expand(char *s1, char *s2)
{
    char lastc;
    const char *s;
    const char *tab[] = {
        "abcdefghijklmnopqrstuvwxyz",
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        "0123456789",
        NULL
    };

    lastc = '?';    /* ? is not expanded, so proper initializer */
    while (*s1) {
        switch(*s1) {
            case '-':
                s = index(tab, lastc, s1[1]);
                if (s) {
                    s1++;
                    while (*s != *s1)
                        *s2++ = *++s;    /* *s1 already copied, so *++s */
                    break;
                }
                /* no break */
            default:
                *s2++ = *s1;
        }
        lastc = *s1++;
    }
    *s2 = '\0';
}

main()
{
    char *test[] = {
        "a-z",
        "A-Z",
        "0-9",
        "a-zA-Z0-9",
        "a-b-c",
        "0-3-9",
        "c-w",
        "3-7",
        "a-h-z",
        "-a-z-",
        "--a--z--0-90--9--",
        "z-a",
        "a-a",
        "-z-w-",
        "- alphabets are a-z -",
        "--",
        "-",
        "",
    };
    int i;
    char buf[100];

    for (i = 0; i < sizeof(test)/sizeof(test[0]); i++) {
        printf("\"%s\" expands to ", test[i]);
        expand(test[i], buf);
        printf("\"%s\"\n", buf);
    }

    return 0;
}


/* end of 3-03-3.c */
