/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 3-5 (p.64): Write the function itob(n,s,b) that converts the integer n into a
 *             base b character representation in the string s. In particular,
 *             itob(n,s,16) formats n as a hexadecimal integer in s.
 *
 * itob() in this answer support 2 to 36 (inclusive) for b (base). For b > 10,
 * 'a' to 'z' represents 10 to 35 respectively.
 *
 * If you wonder what trunc in itob() is for, see 3-04-1.c.
 */

#include <string.h>

#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
#include <errno.h>
#include <time.h>
#include <assert.h>

/* reverse() from K&R2 */
void reverse(char s[])
{
    int c, i, j;

    for (i = 0, j = strlen(s)-1; i < j; i++, j--) {
        c = s[i];
        s[i] = s[j];
        s[j] = c;
    }
}

void itob(int n, char s[], int b)
{
    int trunc;
    int i, r, sign;
    char digit[] = "0123456789abcdefghijklmnopqrstuvwxyz";

    if (b < 2 || b > 36) {
        s[0] = '\0';
        return;
    }

    trunc = (-3 % 2 < 0);

    if ((sign = n) > 0)
        n = -n;
    i = 0;
    do {
        r = n % b;
        s[i++] = digit[(trunc || r == 0)? -r: b - r];
        n /= b;
        if (!trunc && r != 0)
            n += 1;
    } while(n != 0);
    if (sign < 0)
        s[i++] = '-';
    s[i] = '\0';
    reverse(s);
}

main()
{
    time_t t;
    int b, i, j;
    unsigned seed;
    char buf[CHAR_BIT*sizeof(int)+1+1], *p;

    t = time(NULL);
    assert(t != (time_t)-1);

    /* gets seed from time() */
    seed = 0;
    for (i = 0; i < sizeof(t); i++)
        seed += ((unsigned char *)&t)[i];
    srand(seed);

    /* see 3-04-1.c for the infinite loop below */
    i = INT_MIN;
    while (1) {
        b = (int)(((double)rand() / RAND_MAX) * 34) + 2;    /* [2, 36] */
        itob(i, buf, b);
        errno = 0;
        j = strtol(buf, &p, b);
        if (errno != 0 || (j == 0 && *p != '\0') || i != j)
            printf("failed -- %s given for %d\n", buf, i);
        if (i % (INT_MAX / 500) == 0) {
            if (i < 0)
                printf("%.1f%% done\n", (double)(INT_MIN-i) * 50 / -INT_MAX);
            else
                printf("%.1f%% done\n", (double)i * 50 / INT_MAX + 50);
        }
        if (i == INT_MAX)
            break;
        i++;
    }

    return 0;
}


/* end of 3-05.c */
