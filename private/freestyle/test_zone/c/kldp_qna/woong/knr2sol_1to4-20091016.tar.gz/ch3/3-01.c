/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 3-1 (p.58): Our binary search makes two tests inside the loop, when one would
 *             suffice (at the price of more tests outside). Write a version
 *             with only one test inside the loop and measure the difference in
 *             run-time.
 *
 * binsearch() is revised to have only one test in the iteration by deferring
 * the equiality test (x == v[]) after termination of the iteration. A few
 * things worth noting are that:
 * - high is initialized to be n rather than n-1 in order to handle the n == 0
 *   case (which means there are no elements in the array);
 * - (high = mid) cannot be (high = mid - 1) in the "then" branch below because
 *   there is no equality test (i.e., x == v[mid]) any more and
 * - the if statement cannot be "if (x < v[mid]) high = mid-1; else low = mid;"
 *   because of the direction of truncating the result from integer division
 *   (high == low+1 would reulst in infinite iteration).
 *
 * As you can see from the comparison result, there is no significant difference
 * between the performance of the original version and that of the revised one.
 * Since knr_binsearch() stops when x matches v[mid], there are cases where it
 * runs faster than binsearch() that foregoes those early matches. On the other
 * hand, since binsearch() performs fewer comparisons than knr_binsearch() does
 * in general, it runs faster when n is large enough.
 *
 * Note also that the expression to get mid might overflow, which leads to
 * unpredictable result. One way to solve the problem is to replace the
 * expression in question with (mid = low + (high-low)/2).
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* binsearch() from K&R2 for comparison */
int knr_binsearch(int x, int v[], int n)
{
    int low, high, mid;

    low = 0;
    high = n - 1;
    while (low <= high) {
        mid = (low+high)/2;
        if (x < v[mid])
            high = mid - 1;
        else if (x > v[mid])
            low = mid + 1;
        else    /* found match */
            return mid;
    }
    return -1;    /* no match */
}

int binsearch(int x, int v[], int n)
{
    int low, high, mid;

    low = 0;
    high = n;
    while (low < high) {
        mid = (high+low)/2;    /* might overflow */
        if (x <= v[mid])
            high = mid;
        else
            low = mid + 1;
    }

    if (low < n && v[low] == x)
        return low;
    else
        return -1;
}

#define N 100
#define M 10000

main()
{
    int i, j;
    int array[N];
    int x[M], result[M];
    time_t t1, t2;
    unsigned seed;

    t1 = time(NULL);
    assert(t1 != (time_t)-1);

    /* gets seed from time() */
    seed = 0;
    for (i = 0; i < sizeof(t1); i++)
        seed += ((unsigned char *)&t1)[i];
    srand(seed);

    /* prepares sample array */
    i = j = 0;
    while (i < N) {
        if ((double)rand() / RAND_MAX > 0.5)
            array[i++] = j;
        j++;
    }

    /* compares results */
    for (i = 0; i < M; i++) {
        x[i] = rand() % (N * 2);
        result[i] = knr_binsearch(x[i], array, N);
    }

    for (i = 0; i < M; i++) {
        int r;
        r = binsearch(x[i], array, N);
        if (result[i] != r)
            printf("failed when x=%d; %d should be %d\n", x[i], r, result[i]);
    }

    /* compares execution time */
    t1 = time(NULL);
    assert(t1 != (time_t)-1);

    for (i = 0; i < M; i++)
        for (j = 0; j < M; j++)
            result[j] = knr_binsearch(x[j], array, N);

    t2 = time(NULL);
    assert(t2 != (time_t)-1);

    printf("knr_binsearch: %.1f secs\n", difftime(t2, t1));

    t1 = time(NULL);
    assert(t1 != (time_t)-1);

    for (i = 0; i < M; i++)
        for (j = 0; j < M; j++)
            result[j] = knr_binsearch(x[j], array, N);

    t2 = time(NULL);
    assert(t2 != (time_t)-1);

    printf("binsearch: %.1f secs\n", difftime(t2, t1));

    return 0;
}


/* end of 3-01.c */
