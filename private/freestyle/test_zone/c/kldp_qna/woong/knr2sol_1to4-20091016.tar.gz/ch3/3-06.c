/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 3-6 (p.64): Write a version of itoa that accets three arguments instead of
 *             two. The third argument is a minimum field width; the converted
 *             number must be padded with blanks on the left if necessary to
 *             make it wide enough.
 *
 * If you wonder what trunc in itoa() is for, see 3-04-1.c.
 */

#include <string.h>

#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>

/* reverse() from K&R2 */
void reverse(char s[])
{
    int c, i, j;

    for (i = 0, j = strlen(s)-1; i < j; i++, j--) {
        c = s[i];
        s[i] = s[j];
        s[j] = c;
    }
}

/* itoa() from K&R2 */
void knr_itoa(int n, char s[])
{
    int i, sign;

    if ((sign = n) < 0)    /* record sign */
        n = -n;            /* make n positive */
    i = 0;
    do {        /* generate digits in reverse order */
        s[i++] = n % 10 + '0';    /* get next digit */
    } while ((n /= 10) > 0);      /* delete it */
    if (sign < 0)
        s[i++] = '-';
    s[i] = '\0';
    reverse(s);
}

void itoa(int n, char s[], int w)
{
    int trunc;
    int i, r, sign;

    trunc = (-3 % 2 < 0);

    if ((sign = n) > 0)
        n = -n;
    i = 0;
    do {
        r = n % 10;
        s[i++] = '0' + ((trunc || r == 0)? -r: 10 - r);
        n /= 10;
        if (!trunc && r != 0)
            n += 1;
    } while(n != 0);
    if (sign < 0)
        s[i++] = '-';
    while (i < w)    /* adds padding if necessary */
        s[i++] = ' ';
    s[i] = '\0';
    reverse(s);
}

main()
{
    time_t t;
    int i, w, n;
    unsigned seed;
    char buf1[CHAR_BIT*sizeof(int)/3+1+1 + 20],
         buf2[CHAR_BIT*sizeof(int)/3+1+1];

    t = time(NULL);
    assert(t != (time_t)-1);

    /* gets seed from time() */
    seed = 0;
    for (i = 0; i < sizeof(t); i++)
        seed += ((unsigned char *)&t)[i];
    srand(seed);

    /* see 3-04-1.c for the infinite loop below */
    i = INT_MIN;
    while (1) {
        w = ((double)rand() / RAND_MAX) * 20;    /* [0, 20] */
        itoa(i, buf1, w);
        knr_itoa(i, buf2);

        n = 0;
        if (buf1[0] == ' ') {    /* padded */
            for (n = 1; buf1[n] == ' '; n++)    /* counts padding spaces */
                continue;
            if (strlen(buf1) != w)
                printf("failed - incorrect padding for itoa(%d, buf1, %d)\n",
                       i, w);
        }
        if (strcmp(buf1+n, buf2) != 0)
            printf("failed - knr_itoa() gives %s and itoa() gives %s for %d\n",
                   buf1+n, buf2, i);
        if (i % (INT_MAX / 500) == 0) {
            if (i < 0)
                printf("%.1f%% done\n", (double)(INT_MIN-i) * 50 / -INT_MAX);
            else
                printf("%.1f%% done\n", (double)i * 50 / INT_MAX + 50);
        }
        if (i == INT_MAX)
            break;
        i++;
    }

    return 0;
}


/* end of 3-06.c */
