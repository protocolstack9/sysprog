/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-10-14
 *
 * 3-4 (p.64): In a two's complement number representation, our version of itoa
 *             does not handle the largest negative number, that is, the value
 *             of n equal to -(2 ** (wordsize-1)) (where x ** y means x to the
 *             power y). Explain why not. Modify it to print that value
 *             correctly regardless of the machine on which it runs.
 *
 * The explanatory answer is given in 3-04-1.c.
 *
 * This answer takes advantage of the fact that unsigned types do not overflow.
 * To explain the method used in this solution, see what these two expressions
 * do when n is negative (where u declared as unsigned):
 *     u = n;  means u = (UINT_MAX) + n;
 *     u = -u; means u = (UINT_MAX) - u;
 * What u has at the end is
 *     (UINT_MAX) - ((UINT_MAX) + n)
 * so u has the absolute value of n without overflow.
 *
 * This solution, however, does not work on a peculiar implementation where
 * UINT_MAX equals to INT_MAX (which means there are padding bits in the
 * unsigned type); on such an implementation, itoa() gives 0 for INT_MIN.
 */

#include <string.h>

#include <stdio.h>
#include <limits.h>

#if INT_MAX == UINT_MAX
#error "This code does not work if INT_MAX == UINT_MAX!"
#endif

/* reverse() from K&R2 */
void reverse(char s[])
{
    int c, i, j;

    for (i = 0, j = strlen(s)-1; i < j; i++, j--) {
        c = s[i];
        s[i] = s[j];
        s[j] = c;
    }
}

/* itoa() from K&R2 */
void knr_itoa(int n, char s[])
{
    int i, sign;

    if ((sign = n) < 0)    /* record sign */
        n = -n;            /* make n positive */
    i = 0;
    do {        /* generate digits in reverse order */
        s[i++] = n % 10 + '0';    /* get next digit */
    } while ((n /= 10) > 0);      /* delete it */
    if (sign < 0)
        s[i++] = '-';
    s[i] = '\0';
    reverse(s);
}

void itoa(int n, char s[])
{
    int i;
    unsigned u;

    /* n keeps original sign, so sign unnecessary */
    u = n;
    if (n < 0)
        u = -u;    /* u has absolute value of n without overflow */
    i = 0;
    do {
        s[i++] = u % 10 + '0';
    } while ((u /= 10) > 0);
    if (n < 0)
        s[i++] = '-';
    s[i] = '\0';
    reverse(s);
}

main()
{
    int i;
    unsigned u;
    char buf1[CHAR_BIT*sizeof(int)/3+1+1],
         buf2[CHAR_BIT*sizeof(int)/3+1+1];

    /* see 3-04-1.c for the infinite loop below */
    i = INT_MIN;
    while (1) {
        knr_itoa(i, buf1);    /* UB when i == INT_MIN */
        itoa(i, buf2);
        if (strcmp(buf1, buf2) != 0)
            printf("failed - knr_itoa() gives %s and itoa() gives %s for %d\n",
                   buf1, buf2, i);
        if (i % (INT_MAX / 500) == 0) {
            if (i < 0)
                printf("%.1f%% done\n", (double)(INT_MIN-i) * 50 / -INT_MAX);
            else
                printf("%.1f%% done\n", (double)i * 50 / INT_MAX + 50);
        }
        if (i == INT_MAX)
            break;
        i++;
    }

    return 0;
}


/* end of 3-04-3.c */
