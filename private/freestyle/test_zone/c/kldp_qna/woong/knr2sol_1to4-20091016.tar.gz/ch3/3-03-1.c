/*
 * Answers to K&R2 Exercises by Jun Woong (woong.jun@gmail.com)
 *  - last modified on 2009-09-21
 *
 * 3-3 (p.63): Write a function expand(s1,s2) that expands shorthand notations
 *             like a-z in the string s1 into the equivalent complete list
 *             abc...xyz in s2. Allow for letters of either case and digits, and
 *             be prepared to handle cases like a-b-c and a-z0-9 and -a-z.
 *             Arrange that a leading or trailing - is taken literally.
 *
 * Some tricky cases to handle include "a-a" (which is expanded to "a" in this
 * answer), "z-a" and "a-9" (both of which are not expanded in this answer).
 * Changing code to expand "z-a" to "zyx...cba" can be achieved by changing the
 * direction of the loops that copy lower, upper and digit depending on s and e.
 *
 * Initializing an array of char with a string literal appears in 2.4 during
 * explaining the const quialifier, thus also used here.
 *
 * This answer can be much clearer if the pointer arithmetic (rather thatn the
 * array indexing), and the check for ensuring that e is equal to or larger than
 * s can be removed by changing the arguments to index(). Also, index() can be
 * replaced by strchr().
 */

#include <stdio.h>

int index(char tab[], int c)
{
    int i;

    for (i = 0; tab[i] != '\0'; i++)
        if (tab[i] == c)
            return i;

    return -1;
}

void expand(char s1[], char s2[])
{
    int i, j, k;
    int s, e;
    char lastc;
    char lower[] = "abcdefghijklmnopqrstuvwxyz";
    char upper[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    char digit[] = "0123456789";

    j = 0;
    lastc = '?';    /* ? is not expanded, so proper initializer */
    for (i = 0; s1[i] != '\0'; i++) {
        if (s1[i] == '-') {
            if ((s = index(lower, lastc)) != -1 &&
                (e = index(lower, s1[i+1])) != -1 && e >= s) {
                /* s1[i] already copied; so starts at s+1 */
                for (k = s+1; k <= e; k++)
                    s2[j++] = lower[k];
                i++;
            } else if ((s = index(upper, lastc)) != -1 &&
                       (e = index(upper, s1[i+1])) != -1 && e >= s) {
                /* s1[i] already copied; so starts at s+1 */
                for (k = s+1; k <= e; k++)
                    s2[j++] = upper[k];
                i++;
            } else if ((s = index(digit, lastc)) != -1 &&
                       (e = index(digit, s1[i+1])) != -1 && e >= s) {
                /* s1[i] already copied; so starts at s+1 */
                for (k = s+1; k <= e; k++)
                    s2[j++] = digit[k];
                i++;
            } else {
                s2[j++] = s1[i];
            }
        } else {
            s2[j++] = s1[i];
        }
        lastc = s1[i];
    }
    s2[j] = '\0';
}

main()
{
    char *test[] = {
        "a-z",
        "A-Z",
        "0-9",
        "a-zA-Z0-9",
        "a-b-c",
        "0-3-9",
        "c-w",
        "3-7",
        "a-h-z",
        "-a-z-",
        "--a--z--0-90--9--",
        "z-a",
        "a-a",
        "-z-w-",
        "- alphabets are a-z -",
        "--",
        "-",
        ""
    };
    int i;
    char buf[100];

    for (i = 0; i < sizeof(test)/sizeof(test[0]); i++) {
        printf("\"%s\" expands to ", test[i]);
        expand(test[i], buf);
        printf("\"%s\"\n", buf);
    }

    return 0;
}


/* end of 3-03-1.c */
